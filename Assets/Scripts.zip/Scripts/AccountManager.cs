using JetBrains.Annotations;
using System.Collections.Generic;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using TMPro;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.EventSystems;
using UnityEngine.InputSystem;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class AccountManager : MonoBehaviour
{
    public Transform studentContainer;
    public Transform teacherContainer;

    public AccountCardUI selectedCard;

    public AccountData selectedAccount;

    public GameObject accountCardPrefab;

    public TMP_InputField usernameInputField;
    public TMP_InputField passwordInputField;

    public TMP_InputField classroomNameInput;

    private AccountType pendingAccountType;

    public static AccountManager Instance;

    [Header("Panels")]
    public GameObject accountButton;
    public GameObject backButton;
    public GameObject accountSelectPanel;
    public GameObject accountManagementPanel;
    public GameObject createAccountPanel;
    public GameObject mainMenu;
    public GameObject classroomPanel;
    public GameObject classroomSelectionPanel;
    public GameObject classroomCreationPanel;

    [Header("Teacher Monitoring")]
    public GameObject teacherInfoPanel;
    public GameObject studentInfoPanel;

    public GameObject assignStudentsButton;
    public GameObject confirmAssignButton;

    private bool assigningStudents = false;
    public bool IsAssigningStudents => assigningStudents;

    private bool waitingToStartGame = false;
    private bool waitingToLoadGame = false;

    private bool isAccountMenuSynchronizing = false;

    private AccountData assigningTeacher;
    private List<AccountData> pendingStudents = new();

    [Header("Teacher Info")]
    public TextMeshProUGUI teacherNameText;
    public TextMeshProUGUI teacherSectionText;
    public TMP_Text teacherProgressText;
    public TMP_Text teacherMetricsText;

    public Transform assignedStudentContainer;

    [Header("Student Info")]
    public TextMeshProUGUI completedLevelsText;

    public TextMeshProUGUI quizStatsText;

    public AccountRegistry registry = new();

    private AccountData pendingLoginAccount;
    public GameObject loginPanel;
    public TMP_InputField loginPasswordInput;
    public TMP_Text loginUsernameText;

    public GameObject cardDeck;

    [Header("Recovery Code Display")]
    public GameObject accountRecoveryDisplay;
    public TMP_Text recoveryCodeText;
    public Button confirmRecoveryCodeButton;

    [Header("Account Recovery")]
    public GameObject accountRecoveryPanel;
    public Button accountRecoveryButton;
    public Button cancelAccountRecoveryButton;
    public TMP_InputField recoveryCodeInputField;
    public TMP_InputField newPasswordInputField;
    public TMP_InputField confirmPasswordInputField;
    public Button confirmAccountRecoveryButton;

    private string pendingRecoveryCode;
    private bool creatingAccount = false;
    private bool synchronizingPendingAccounts = false;

    private string registryPath => Application.persistentDataPath + "/accounts.json";

    private string pendingAccountsPath => Application.persistentDataPath + "/pending_accounts.json";

    private string pendingDeletionsPath => Path.Combine(Application.persistentDataPath, "pending_account_deletions.json");

    private PendingAccountDeletions pendingAccountDeletions = new PendingAccountDeletions();

    private PendingAccountUploads pendingAccountUploads = new PendingAccountUploads();
    private string pendingAssignmentsPath => Application.persistentDataPath + "/pending_assignments.json";

    private PendingAccountUploads pendingAssignmentUploads = new PendingAccountUploads();

    private bool synchronizingAssignments = false;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {

    }

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;

            DontDestroyOnLoad(gameObject);

            EnsureAccountsFileExists();
        }

        else
        {
            Destroy(gameObject);
        }

        EnsureAccountsFileExists();
        LoadPendingAccountUploads();
        LoadPendingAssignmentUploads();
        LoadPendingAccountDeletions();

        CheckInterruptedAccountDeletions();
    }

    public void LoadAccount()
    {
        if (!File.Exists(registryPath))
        {
            SaveAccount();
            return;
        }

        string json = File.ReadAllText(registryPath);

        registry = JsonUtility.FromJson<AccountRegistry>(json);

        if (registry == null)
        {
            registry = new AccountRegistry();
        }
    }

    public void SaveAccount()
    {
        string json = JsonUtility.ToJson(registry, true);

        File.WriteAllText(registryPath, json);
    }
    public async void CreateStudentAccount()
    {
        bool success = await CreateAccount(AccountType.Student);

        if (!success)
        {
            Debug.LogWarning("Student account creation failed.");
        }
    }

    public async void CreateTeacherAccount()
    {
        bool success = await CreateAccount(AccountType.Teacher);

        if (!success)
        {
            Debug.LogWarning("Teacher account creation failed.");
        }
    }

    public Task<bool> CreateAccount(AccountType type)
    {
        string username = usernameInputField.text.Trim();

        if (string.IsNullOrWhiteSpace(username))
        {
            Debug.LogWarning("No Username Entered");
            return Task.FromResult(false);
        }

        string password = passwordInputField.text.Trim();

        if (string.IsNullOrWhiteSpace(password))
        {
            Debug.LogWarning("No Password Entered");
            return Task.FromResult(false);
        }

        AccountData newAccount = new AccountData();

        newAccount.id = System.Guid.NewGuid().ToString();
        newAccount.classroomID = DatabaseManager.Instance.CurrentDatabase;
        newAccount.username = username;
        newAccount.passwordHash = HashPassword(password);
        newAccount.accountType = type;

        string recoveryCode = GenerateRecoveryCode();

        newAccount.recoveryCodeHash = HashRecoveryCode(recoveryCode);
        newAccount.recoveryCodeEnabled = true;

        try
        {
            // Save locally first, without waiting for Firestore.
            registry.accounts.Add(newAccount);

            // Record the account as awaiting Firestore upload.
            pendingAccountUploads.accountIDs.Add(newAccount.id);

            try
            {
                SavePendingAccountUploads();
                SaveAccount();
            }

            catch
            {
                pendingAccountUploads.accountIDs.Remove(newAccount.id);
                SavePendingAccountUploads();
                throw;
            }

            // Only expose the recovery code after local saving succeeds.
            pendingRecoveryCode = recoveryCode;

            Debug.Log(
                "Created account locally: " + newAccount.username
            );
        }
        catch (System.Exception ex)
        {
            registry.accounts.Remove(newAccount);

            pendingRecoveryCode = null;

            Debug.LogError(
                "Failed to save account locally: " + ex.Message
            );

            return Task.FromResult(false);
        }

        usernameInputField.text = "";
        passwordInputField.text = "";

        RefreshUI();

        return Task.FromResult(true);
    }

    private bool deletingAccount = false;
    private bool loginInProgress = false;

    public async void DeleteSelected()
    {
        if (deletingAccount || selectedAccount == null)
            return;

        if (loginInProgress)
        {
            Debug.LogWarning(
                "Account deletion blocked: Login is still loading account progress."
            );

            return;
        }

        if (resettingPassword)
        {
            Debug.LogWarning(
                "Account deletion blocked: Password recovery is still in progress."
            );

            return;
        }

        AccountData accountToDelete = selectedAccount;
        string accountID = accountToDelete.id;

        if (string.IsNullOrWhiteSpace(accountID))
            return;

        // Prevent deletion while the initial account upload is pending.
        if (synchronizingPendingAccounts)
        {
            Debug.LogWarning(
                "Cannot delete an account while account uploads are synchronizing."
            );
            return;
        }

        bool isPendingUpload = IsAccountPendingUpload(accountID);

        if (synchronizingAssignments)
        {
            Debug.LogWarning(
                "Cannot delete an account while assignments are synchronizing."
            );
            return;
        }

        if (FirestoreManager.Instance == null ||
            DatabaseManager.Instance == null ||
            string.IsNullOrWhiteSpace(DatabaseManager.Instance.CurrentDatabase) ||
            DatabaseManager.Instance.CurrentDatabase == "DefaultDatabase")
        {
            Debug.LogWarning(
                "Account deletion blocked: No active Classroom or Firestore connection."
            );
            return;
        }

        string classroomID = DatabaseManager.Instance.CurrentDatabase;

        if (accountToDelete.classroomID != classroomID)
        {
            Debug.LogWarning(
                "Account deletion blocked: Account belongs to another classroom."
            );
            return;
        }

        ProgressManager progressManager = ProgressManager.Instance;

        if (progressManager == null)
        {
            Debug.LogError(
                "Account deletion cancelled: ProgressManager is unavailable."
            );
            return;
        }

        if (progressManager.IsAccountDeletionInProgress)
        {
            Debug.LogWarning(
                "Account deletion cancelled: Another deletion is in progress."
            );
            return;
        }

        deletingAccount = true;

        progressManager.BeginAccountDeletion(accountID);

        try
        {
            Debug.Log("Waiting for outstanding account downloads.");

            await FirestoreAccountManager.WaitForAccountDownloads();

            Debug.Log("Waiting for outstanding progress synchronization operations.");

            await progressManager.WaitForBackgroundOperations();

            Debug.Log("Waiting for outstanding Firestore account operations: " + accountID);

            await FirestoreAccountManager.WaitForAccountOperations(accountID);

            // Persist deletion intent before making destructive
            // changes to Firestore.
            MarkAccountPendingDeletion(classroomID, accountID);

            // Delete the account's Firestore progress before deleting
            // the account document itself.
            await FirestoreAccountManager.DeleteAccountProgress(accountID, classroomID: classroomID);

            // Delete the account document only after progress cleanup succeeds.
            await FirestoreAccountManager.DeleteAccount(accountID, classroomID);

            // Ensure the Classroom hasn't changed during the operation.
            if (DatabaseManager.Instance.CurrentDatabase != classroomID)
            {
                Debug.LogWarning("Account deleted from Firestore, but local cleanup was cancelled " + "because the active Classroom changed.");
                return;
            }

            // Remove the local progress file.
            string saveFile = Path.Combine(
                Application.persistentDataPath,
                "progress_" + accountID + ".json"
            );

            if (File.Exists(saveFile))
            {
                File.Delete(saveFile);
            }

            // Remove the account from the local registry.
            registry.accounts.RemoveAll(a => a.id == accountID);

            if (isPendingUpload)
            {
                pendingAccountUploads.accountIDs.Remove(accountID);
                SavePendingAccountUploads();
            }

            // Remove deleted students from teacher assignments.
            foreach (AccountData account in registry.accounts)
            {
                if (account.assignedStudentIDs != null &&
                    account.assignedStudentIDs.Remove(accountID) &&
                    account.accountType == AccountType.Teacher)
                {
                    QueueAssignmentUpload(account.id);
                }
            }

            // Remove any queued assignment upload for the deleted account.
            pendingAssignmentUploads.accountIDs.Remove(accountID);
            SavePendingAssignmentUploads();

            if (CurrentAccount.ActiveAccount != null &&
                CurrentAccount.ActiveAccount.id == accountID)
            {
                progressManager.ClearDeletedAccountState(accountID);
                CurrentAccount.ActiveAccount = null;
            }

            selectedAccount = null;
            selectedCard = null;

            SaveAccount();

            ClearAccountPendingDeletion(classroomID, accountID);

            RefreshUI();

            Debug.Log("Account deleted locally and from Firestore: " + accountToDelete.username);
        }

        catch (System.Exception ex)
        {
            Debug.LogError(
            "Account deletion failed for " + accountID +
            ". The account may have been partially deleted from Firestore. " +
            "Local account data has been retained where cleanup did not complete. " +
            "Error: " + ex
            );
        }

        finally
        {
            progressManager.EndAccountDeletion(accountID);

            deletingAccount = false;

            // Resume pending teacher assignment synchronization
            // after the deletion guard has been released.
            if (pendingAssignmentUploads.accountIDs.Count > 0)
            {
                _ = SynchronizePendingAssignments();
            }
        }
    }


    public void RefreshUI()
    {
        Debug.Log("RefreshUI Started");

        if (studentContainer == null)
        {
            Debug.LogError("Student Container NULL");
            return;
        }

        if (teacherContainer == null)
        {
            Debug.LogError("Teacher Container NULL");
            return;
        }

        if (accountCardPrefab == null)
        {
            Debug.LogError("Account Card Prefab NULL");
            return;
        }

        // Clear old cards
        for (int i = studentContainer.childCount - 1; i >= 0; i--)
        {
            Destroy(studentContainer.GetChild(i).gameObject);
        }

        for (int i = teacherContainer.childCount - 1; i >= 0; i--)
        {
            Destroy(teacherContainer.GetChild(i).gameObject);
        }

        Debug.Log("Cleared old cards");

        // Sort accounts alphabetically by username (A-Z).
        string activeClassroomID = DatabaseManager.Instance.CurrentDatabase;

        List<AccountData> sortedAccounts = registry.accounts.FindAll(
            account =>
                account != null &&
                account.classroomID == activeClassroomID
        );

        sortedAccounts.Sort((a, b) => string.Compare(a.username, b.username, System.StringComparison.OrdinalIgnoreCase));

        foreach (AccountData account in sortedAccounts)
        {
            Transform parent =
                account.accountType == AccountType.Student
                ? studentContainer
                : teacherContainer;

            GameObject obj =
                Instantiate(accountCardPrefab, parent);

            obj.SetActive(true);

            Debug.Log("Instantiated card object");

            AccountCardUI card =
                obj.GetComponent<AccountCardUI>();

            if (card == null)
            {
                Debug.LogError("AccountCardUI component missing");
                continue;
            }

            card.Setup(account);

            Debug.Log("Spawned UI Card for: " + account.username);
        }

        RefreshAccountHighlights();
        Debug.Log("RefreshUI Finished");
    }

    public void RefreshAccountHighlights()
    {
        string activeAccountID =
            CurrentAccount.ActiveAccount != null
            ? CurrentAccount.ActiveAccount.id
            : null;

        RefreshContainerHighlights(studentContainer, activeAccountID);
        RefreshContainerHighlights(teacherContainer, activeAccountID);
    }

    private void RefreshContainerHighlights(
        Transform container,
        string activeAccountID)
    {
        if (container == null)
            return;

        foreach (Transform child in container)
        {
            AccountCardUI card = child.GetComponent<AccountCardUI>();

            if (card == null)
                continue;

            AccountData account = card.GetAccountData();

            if (account == null)
                continue;

            bool shouldHighlight;

            if (assigningStudents &&
                account.accountType == AccountType.Student)
            {
                shouldHighlight = pendingStudents.Exists(
                    student => student.id == account.id
                );
            }
            else
            {
                shouldHighlight =
                    !string.IsNullOrEmpty(activeAccountID) &&
                    account.id == activeAccountID;
            }

            card.SetSelected(shouldHighlight);
        }
    }

    public async void SubmitUsername()
    {
        // Prevent multiple submissions.
        if (creatingAccount)
        {
            return;
        }

        creatingAccount = true;

        try
        {
            bool accountCreated = await CreateAccount(pendingAccountType);

            if (!accountCreated)
            {
                Debug.LogWarning("Account creation failed.");
                return;
            }

            // Prevent additional submissions after successful creation.
            Button submitButton = null;

            if (usernameInputField != null)
            {
                submitButton = usernameInputField.GetComponentInParent<Button>();
            }

            // The account has already been created successfully.
            // Keep the submission guard active until the recovery code is confirmed.

            // Display the generated recovery code.
            recoveryCodeText.text = pendingRecoveryCode;

            accountRecoveryDisplay.SetActive(true);

            Debug.Log("Account created. Recovery code displayed.");
        }

        catch (System.Exception ex)
        {
            Debug.LogError("Unexpected account creation error: " + ex.Message);
        }

        finally
        {
            // Keep submissions blocked while the recovery code is displayed.
            if (!accountRecoveryDisplay.activeSelf)
            {
                creatingAccount = false;
            }
        }
    }

    public void ConfirmRecoveryCode()
    {
        pendingRecoveryCode = null;

        recoveryCodeText.text = "";

        creatingAccount = false;

        accountRecoveryDisplay.SetActive(false);

        createAccountPanel.SetActive(false);

        accountSelectPanel.SetActive(true);

        ShowAccountManagementPanel();

        backButton.SetActive(true);

        if (classroomPanel != null)
        {
            classroomPanel.SetActive(true);
        }

        RefreshUI();

        // Upload the newly created account to Firestore.
        // If the upload fails, it remains queued for synchronization.
        _ = SynchronizePendingAccounts();
    }

    private void ReIndexAccounts()
    {
        for (int i = 0; i < registry.accounts.Count; i++)
        {
            registry.accounts[i].id = i.ToString();
        }
    }

    public void SelectAccount(AccountCardUI card)
    {
        if (deletingAccount)
        {
            Debug.LogWarning("Cannot select another account while account deletion is in progress.");
            return;
        }

        AccountData clickedAccount = card.GetAccountData();

        if (clickedAccount == null)
        {
            Debug.LogWarning("Cannot select account: Account data is missing.");
            return;
        }

        if (IsAccountPendingDeletion(clickedAccount.id))
        {
            Debug.LogWarning(
                "Cannot select account because deletion is pending: " +
                clickedAccount.id
            );

            return;
        }

        if (assigningStudents)
        {
            if (clickedAccount.accountType != AccountType.Student)
                return;

            bool alreadySelected = pendingStudents.Exists(
                student => student.id == clickedAccount.id
            );

            if (alreadySelected)
            {
                pendingStudents.RemoveAll(
                    student => student.id == clickedAccount.id
                );

                card.SetSelected(false);
            }
            else
            {
                pendingStudents.Add(clickedAccount);

                card.SetSelected(true);
            }

            return;
        }

        selectedCard = card;

        RefreshAccountHighlights();

        pendingLoginAccount = card.GetAccountData();

        loginUsernameText.text = "Login: " + pendingLoginAccount.username;

        loginPasswordInput.text = "";

        ShowLoginPanel();
    }

    public async void ConfirmLogin()
    {
        if (deletingAccount)
        {
            Debug.LogWarning("Cannot log into another account while account deletion is in progress.");
            return;
        }

        if (loginInProgress)
        {
            Debug.LogWarning("Login is already in progress.");
            return;
        }

        if (pendingLoginAccount == null)
            return;

        if (IsAccountPendingDeletion(pendingLoginAccount.id))
        {
            Debug.LogWarning(
                "Cannot log into account because deletion is pending: " +
                pendingLoginAccount.id
            );

            return;
        }

        string enteredPassword = loginPasswordInput.text.Trim();
        string enteredHash = AccountManager.HashPassword(enteredPassword);

        if (enteredHash != pendingLoginAccount.passwordHash)
        {
            Debug.Log("Incorrect Password");
            return;
        }

        loginInProgress = true;

        try
        {
            selectedAccount = pendingLoginAccount;

            CurrentAccount.ActiveAccount = selectedAccount;

            ProgressManager.Instance.SetActiveAccount(selectedAccount);

            RefreshAccountHighlights();

            loginPanel.SetActive(false);
            RestorePanelsAfterLogin();

            Debug.Log("Logged in as: " + selectedAccount.username);

            if (selectedAccount.accountType == AccountType.Student || selectedAccount.accountType == AccountType.Teacher)
            {
                bool loaded = await ProgressManager.Instance.LoadProgressForActiveAccount();

                if (!loaded)
                {
                    Debug.LogWarning("Account progress could not be fully loaded.");
                }
            }

            if (waitingToStartGame)
            {
                waitingToStartGame = false;

                MainMenu.StartNewGame();
            }

            else if (waitingToLoadGame)
            {
                waitingToLoadGame = false;

                MainMenu mainMenuScript = FindFirstObjectByType<MainMenu>(FindObjectsInactive.Include);

                if (mainMenuScript != null)
                {
                    mainMenuScript.LoadGame();
                }

                else
                {
                    Debug.LogError("AccountManager: MainMenu script not found!");
                }
            }
        }

        catch (System.Exception ex)
        {
            Debug.LogError("Account login encountered an error: " + ex);
        }

        finally
        {
            loginInProgress = false;
        }
    }

    public void CancelLogin()
    {
        pendingLoginAccount = null;

        loginPasswordInput.text = "";

        loginPanel.SetActive(false);
        RestorePanelsAfterLogin();
    }

    private void RestorePanelsAfterLogin()
    {
        PanelHider panelHider = loginPanel.GetComponent<PanelHider>();
        if (panelHider == null)
        {
            Debug.LogError("AccountManager: PanelHider is missing from LoginPanel.", loginPanel);
            return;
        }

        panelHider.RestorePanels();

        if (accountManagementPanel != null && accountManagementPanel.activeSelf)
        {
            HideAccountManagementTitle();
        }

        if (backButton != null)
        {
            backButton.SetActive(true);
        }
    }

    private void ShowLoginPanel()
    {
        loginPanel.SetActive(true);

        PanelHider panelHider = loginPanel.GetComponent<PanelHider>();
        if (panelHider == null)
        {
            Debug.LogError("AccountManager: PanelHider is missing from LoginPanel.", loginPanel);
            return;
        }

        panelHider.HidePanels();
        backButton.SetActive(false);
    }

    private void ShowAccountManagementPanel()
    {
        accountManagementPanel.SetActive(true);
        HideAccountManagementTitle();
    }

    private void HideAccountManagementTitle()
    {
        SetAccountManagementTitleVisible(false);
    }

    private void ShowAccountManagementTitle()
    {
        SetAccountManagementTitleVisible(true);
    }

    private void SetAccountManagementTitleVisible(bool visible)
    {
        Transform canvas = accountManagementPanel.transform.parent;
        if (canvas == null)
        {
            Debug.LogError("AccountManager: AccountManagementPanel has no parent Canvas.", accountManagementPanel);
            return;
        }

        Transform title = canvas.Find("Title");
        if (title == null)
        {
            Debug.LogError("AccountManager: Could not find the Title object under the Canvas.", accountManagementPanel);
            return;
        }

        title.gameObject.SetActive(visible);
    }

    public void OpenAccountRecovery()
    {
        if (pendingLoginAccount == null)
        {
            Debug.LogWarning("AccountManager: No account selected for recovery.");
            return;
        }

        loginPanel.SetActive(false);
        accountRecoveryPanel.SetActive(true);

        Debug.Log("Opening recovery for: " + pendingLoginAccount.username);
    }

    public void CancelAccountRecovery()
    {
        accountRecoveryPanel.SetActive(false);
        ShowLoginPanel();
    }


    private bool resettingPassword = false;

    public async void ConfirmAccountRecovery()
    {
        if (deletingAccount || (ProgressManager.Instance != null && ProgressManager.Instance.IsAccountDeletionInProgress))
        {
            Debug.LogWarning("Account recovery blocked: Account deletion is in progress.");
            return;
        }

        if (resettingPassword)
            return;

        if (pendingLoginAccount == null)
        {
            Debug.LogWarning("No account selected for recovery.");
            return;
        }

        string enteredCode = recoveryCodeInputField.text.Trim().ToUpperInvariant();
        string newPassword = newPasswordInputField.text.Trim();
        string confirmPassword = confirmPasswordInputField.text.Trim();

        // Reject missing fields.
        if (string.IsNullOrWhiteSpace(enteredCode) || string.IsNullOrWhiteSpace(newPassword) || string.IsNullOrWhiteSpace(confirmPassword))
        {
            Debug.LogWarning("Account Recovery: All fields are required.");
            return;
        }

        // Check password confirmation.
        if (newPassword != confirmPassword)
        {
            Debug.LogWarning("Account Recovery: Passwords do not match.");
            return;
        }

        // Check whether this account supports recovery.
        if (!pendingLoginAccount.recoveryCodeEnabled ||
            string.IsNullOrEmpty(pendingLoginAccount.recoveryCodeHash))
        {
            Debug.LogWarning("Account Recovery: No recovery code configured.");
            return;
        }

        // Verify the recovery code.
        string enteredCodeHash = HashRecoveryCode(enteredCode);

        if (enteredCodeHash != pendingLoginAccount.recoveryCodeHash)
        {
            Debug.LogWarning("Account Recovery: Incorrect recovery code.");
            return;
        }

        resettingPassword = true;
        confirmAccountRecoveryButton.interactable = false;

        string previousPasswordHash = pendingLoginAccount.passwordHash;

        try
        {
            // Update the selected account's password hash.
            pendingLoginAccount.passwordHash = HashPassword(newPassword);

            // Save the updated account to Firestore.
            await FirestoreAccountManager.UploadAccount(pendingLoginAccount);

            // Update local account storage.
            SaveAccount();

            Debug.Log("Account Recovery: Password successfully reset.");

            // Clear sensitive inputs.
            recoveryCodeInputField.text = "";
            newPasswordInputField.text = "";
            confirmPasswordInputField.text = "";
            loginPasswordInput.text = "";

            // Return to the login panel.
            accountRecoveryPanel.SetActive(false);
            ShowLoginPanel();
        }
        catch (System.Exception ex)
        {
            // Restore the previous password if uploading failed.
            pendingLoginAccount.passwordHash = previousPasswordHash;

            Debug.LogError("Account Recovery failed: " + ex.Message);
        }
        finally
        {
            resettingPassword = false;
            confirmAccountRecoveryButton.interactable = true;
        }
    }


    public void StartAssignStudents()
    {
        if (selectedAccount == null)
            return;

        if (selectedAccount.accountType != AccountType.Teacher)
            return;

        assigningStudents = true;
        assigningTeacher = selectedAccount;

        pendingStudents.Clear();

        if (assigningTeacher.assignedStudentIDs == null)
            assigningTeacher.assignedStudentIDs = new List<string>();

        // Start with students already assigned to this teacher.
        foreach (AccountData student in registry.accounts)
        {
            if (student.accountType == AccountType.Student &&
                assigningTeacher.assignedStudentIDs.Contains(student.id))
            {
                pendingStudents.Add(student);
            }
        }

        // Highlight students currently selected for assignment.
        foreach (Transform child in studentContainer)
        {
            AccountCardUI card = child.GetComponent<AccountCardUI>();

            if (card == null)
                continue;

            AccountData student = card.GetAccountData();

            card.SetSelected(
                pendingStudents.Exists(s => s.id == student.id)
            );
        }

        assignStudentsButton.SetActive(false);
        confirmAssignButton.SetActive(true);

        Debug.Log("Assignment Mode Started");
    }

    public void ConfirmAssignStudents()
    {
        if (assigningTeacher == null)
            return;

        if (assigningTeacher.assignedStudentIDs == null)
            assigningTeacher.assignedStudentIDs = new List<string>();

        // Save the final selection, including existing assignments
        // that were not deselected.
        assigningTeacher.assignedStudentIDs =
            pendingStudents.ConvertAll(student => student.id);

        SaveAccount();
        QueueAssignmentUpload(assigningTeacher.id);

        assigningStudents = false;
        assigningTeacher = null;

        pendingStudents.Clear();

        assignStudentsButton.SetActive(true);
        confirmAssignButton.SetActive(false);

        // Clear temporary selection colors.
        RefreshAccountHighlights();

        Debug.Log("Student assignments updated.");
    }

    public void PromptForAccountThenStartGame()
    {
        waitingToStartGame = true;

        OpenAccountMenu();
    }

    public void PromptForAccountThenLoadGame()
    {
        waitingToLoadGame = true;
        waitingToStartGame = false;

        OpenAccountMenu();
    }

    void HideAllPanels()
    {
        if (accountSelectPanel != null)
            accountSelectPanel.SetActive(false);

        if (accountManagementPanel != null)
            accountManagementPanel.SetActive(false);

        if (createAccountPanel != null)
            createAccountPanel.SetActive(false);

        if (teacherInfoPanel != null)
            teacherInfoPanel.SetActive(false);

        if (studentInfoPanel != null)
            studentInfoPanel.SetActive(false);

        if (classroomPanel != null)
            classroomPanel.SetActive(false);
    }

    public void OpenAccountMenu()
    {
        Debug.Log("[Account Menu] OpenAccountMenu entered.");

        HideAllPanels();
        Debug.Log("[Account Menu] Existing panels hidden.");

        mainMenu.SetActive(false);
        cardDeck.SetActive(false);
        accountButton.SetActive(false);

        accountSelectPanel.SetActive(true);
        ShowAccountManagementPanel();
        backButton.SetActive(true);
        classroomPanel.SetActive(true);

        Debug.Log("[Account Menu] Account panels activated.");

        _ = SynchronizeAccountMenuAsync();
    }

    public void OpenCreateStudentMenu()
    {
        pendingAccountType = AccountType.Student;

        accountSelectPanel.SetActive(false);

        accountManagementPanel.SetActive(false);

        accountRecoveryDisplay.SetActive(false);

        createAccountPanel.SetActive(true);

        classroomPanel.SetActive(false);

        backButton.SetActive(false);
    }

    public void OpenCreateTeacherMenu()
    {
        pendingAccountType = AccountType.Teacher;

        accountSelectPanel.SetActive(false);

        accountManagementPanel.SetActive(false);

        accountRecoveryDisplay.SetActive(false);

        createAccountPanel.SetActive(true);

        classroomPanel.SetActive(false);

        backButton.SetActive(false);
    }

    public void OpenTeacherInfo(AccountCardUI card)
    {
        AccountData account = card.GetAccountData();

        if (account.accountType != AccountType.Teacher)
            return;

        HideAllPanels();

        teacherInfoPanel.SetActive(true);

        backButton.SetActive(true);

        teacherNameText.text = "Name: " + account.username;

        string section = "No Classroom Selected";

        if (DatabaseManager.Instance != null &&
            !string.IsNullOrWhiteSpace(DatabaseManager.Instance.CurrentDatabase))
        {
            section = DatabaseManager.Instance.CurrentDatabase;
        }

        teacherSectionText.text = "Section: " + section;

        LoadTeacherStats(account);

        foreach (Transform child in assignedStudentContainer)
        {
            Destroy(child.gameObject);
        }

        foreach (string studentID in account.assignedStudentIDs)
        {
            AccountData student = registry.accounts.Find(a => a.id == studentID);

            if (student == null)
                continue;

            GameObject obj = Instantiate(accountCardPrefab, assignedStudentContainer);

            obj.SetActive(true);

            AccountCardUI ui = obj.GetComponent<AccountCardUI>();

            ui.Setup(student, AccountCardMode.TeacherStudentView);
        }
    }

    private void LoadTeacherStats(AccountData teacher)
    {
        string path = Application.persistentDataPath + "/progress_" + teacher.id + ".json";

        if (!System.IO.File.Exists(path))
        {
            teacherProgressText.text = "No Progress has been made on this Account";

            teacherMetricsText.text = "No Progress has been made on this Account";

            return;
        }

        string json = System.IO.File.ReadAllText(path);
        ProgressData data = JsonUtility.FromJson<ProgressData>(json);

        if (data == null)
        {
            teacherProgressText.text = "No Progress has been made on this Account";

            teacherMetricsText.text = "No Progress has been made on this Account";

            return;
        }

        // Completed Levels
        if (data.completedLevel == null || data.completedLevel.Count == 0)
        {
            teacherProgressText.text = "No Completed Levels";
        }

        else
        {
            teacherProgressText.text = "Completed Levels:\n";

            foreach (string level in data.completedLevel)
            {
                teacherProgressText.text += level + "\n";
            }
        }

        // Question Metrics
        int totalAnswered =
            data.multipleChoiceTotal +
            data.identificationTotal +
            data.trueFalseTotal +
            data.multipleSelectTotal; ;

        int totalCorrect =
            data.multipleChoiceCorrect +
            data.identificationCorrect +
            data.trueFalseCorrect +
            data.multipleSelectCorrect;

        if (totalAnswered == 0)
        {
            teacherMetricsText.text = "No Progress has been made on this Account";

            return;
        }

        teacherMetricsText.text =
            "Multiple Choice: " +
            data.multipleChoiceCorrect + "/" +
            data.multipleChoiceTotal + "\n\n" +

            "Identification: " +
            data.identificationCorrect + "/" +
            data.identificationTotal + "\n\n" +

            "True/False: " +
            data.trueFalseCorrect + "/" +
            data.trueFalseTotal + "\n\n" +

            "Multiple Select: " +
            data.multipleSelectCorrect + "/" +
            data.multipleSelectTotal + "\n\n" +

            "Total: " + totalCorrect + "/" + totalAnswered;
    }


    public void OpenStudentInfo(AccountData student)
    {
        studentInfoPanel.SetActive(true);

        string path = Application.persistentDataPath + "/progress_" + student.id + ".json";

        if (!System.IO.File.Exists(path))
        {
            return;
        }

        string json = System.IO.File.ReadAllText(path);

        ProgressData data = JsonUtility.FromJson<ProgressData>(json);

        completedLevelsText.text = "Completed Levels:\n";

        foreach (string level in data.completedLevel)
        {
            completedLevelsText.text += level + "\n";
        }

        quizStatsText.text =
            "Multiple Choice: " + data.multipleChoiceCorrect + "/" + data.multipleChoiceTotal +
            "\n\n" + "Identification: " + data.identificationCorrect + "/" + data.identificationTotal +
            "\n\n" + "True/False: " + data.trueFalseCorrect + "/" + data.trueFalseTotal +
            "\n\n" + "Multiple Select: " + data.multipleSelectCorrect + "/" + data.multipleSelectTotal;
    }
    public void CloseStudentInfo()
    {
        if (studentInfoPanel == null || !studentInfoPanel.activeSelf)
            return;

        studentInfoPanel.SetActive(false);

        Debug.Log("Student Information Panel closed.");
    }

    public void CloseAccountMenu()
    {
        if (MainMenu.IsOptionsMenuOpen)
        {
            return;
        }

        waitingToStartGame = false;
        waitingToLoadGame = false;

        accountButton.SetActive(true);

        mainMenu.SetActive(true);

        accountSelectPanel.SetActive(false);

        accountManagementPanel.SetActive(false);
        ShowAccountManagementTitle();

        createAccountPanel.SetActive(false);

        backButton.SetActive(false);

        teacherInfoPanel.SetActive(false);

        mainMenu.SetActive(true);

        cardDeck.SetActive(true);

        classroomPanel.SetActive(false);
    }

    public void SelectTeacherStudent(AccountCardUI card)
    {
        OpenStudentInfo(card.GetAccountData());
    }

    private void LoadPendingAccountUploads()
    {
        if (!File.Exists(pendingAccountsPath))
        {
            pendingAccountUploads = new PendingAccountUploads();
            return;
        }

        string json = File.ReadAllText(pendingAccountsPath);

        pendingAccountUploads =
            JsonUtility.FromJson<PendingAccountUploads>(json)
            ?? new PendingAccountUploads();

        if (pendingAccountUploads.accountIDs == null)
            pendingAccountUploads.accountIDs = new List<string>();
    }

    private void LoadPendingAssignmentUploads()
    {
        if (!File.Exists(pendingAssignmentsPath))
        {
            pendingAssignmentUploads = new PendingAccountUploads();
            return;
        }

        string json = File.ReadAllText(pendingAssignmentsPath);

        pendingAssignmentUploads =
            JsonUtility.FromJson<PendingAccountUploads>(json)
            ?? new PendingAccountUploads();

        if (pendingAssignmentUploads.accountIDs == null)
            pendingAssignmentUploads.accountIDs = new List<string>();
    }

    private void LoadPendingAccountDeletions()
    {
        if (!File.Exists(pendingDeletionsPath))
        {
            pendingAccountDeletions = new PendingAccountDeletions();
            return;
        }

        string json = File.ReadAllText(pendingDeletionsPath);

        pendingAccountDeletions =
            JsonUtility.FromJson<PendingAccountDeletions>(json)
            ?? new PendingAccountDeletions();

        if (pendingAccountDeletions.accountIDs == null)
        {
            pendingAccountDeletions.accountIDs = new List<string>();
        }

        if (pendingAccountDeletions.records == null)
        {
            pendingAccountDeletions.records = new List<PendingAccountDeletionRecord>();
        }
    }

    private void CheckInterruptedAccountDeletions()
    {
        if (pendingAccountDeletions == null)
        {
            return;
        }

        int legacyCount = pendingAccountDeletions.accountIDs?.Count ?? 0;

        int recordCount = pendingAccountDeletions.records?.Count ?? 0;

        int totalCount = legacyCount + recordCount;

        if (totalCount == 0)
        {
            Debug.Log("Account deletion recovery check: " + "No interrupted deletions detected."
            );

            return;
        }

        Debug.LogWarning("Account deletion recovery check: " + totalCount + " pending deletion record(s) detected."
        );

        if (pendingAccountDeletions.records != null)
        {
            foreach (PendingAccountDeletionRecord record in pendingAccountDeletions.records)
            {
                if (record == null)
                {
                    continue;
                }

                Debug.LogWarning("Pending deletion: Account " + record.accountID + " | Classroom: " + record.classroomID);
            }
        }

        if (pendingAccountDeletions.accountIDs != null)
        {
            foreach (string accountID in pendingAccountDeletions.accountIDs)
            {
                Debug.LogWarning("Legacy pending deletion requires review: " + accountID);
            }
        }
    }

    private bool CanRecoverPendingAccountDeletion(PendingAccountDeletionRecord record)
    {
        if (record == null)
        {
            return false;
        }

        if (string.IsNullOrWhiteSpace(record.classroomID) || string.IsNullOrWhiteSpace(record.accountID))
        {
            Debug.LogWarning("Account deletion recovery skipped: " + "Incomplete deletion record.");

            return false;
        }

        if (deletingAccount)
        {
            return false;
        }

        if (DatabaseManager.Instance == null ||
            FirestoreManager.Instance == null)
        {
            Debug.LogWarning(
                "Account deletion recovery skipped: " +
                "Database managers are unavailable."
            );

            return false;
        }

        string activeClassroom = DatabaseManager.Instance.CurrentDatabase;

        if (string.IsNullOrWhiteSpace(activeClassroom) || activeClassroom == "DefaultDatabase")
        {
            Debug.LogWarning("Account deletion recovery skipped: " + "No valid classroom is active.");

            return false;
        }

        if (record.classroomID != activeClassroom)
        {
            Debug.LogWarning("Account deletion recovery deferred for account " + record.accountID + ": Pending classroom " + record.classroomID +
                " does not match active classroom " + activeClassroom);

            return false;
        }

        return true;
    }

    private void CheckRecoverableAccountDeletions()
    {
        if (pendingAccountDeletions == null || pendingAccountDeletions.records == null || pendingAccountDeletions.records.Count == 0)
        {
            return;
        }

        foreach (PendingAccountDeletionRecord record in pendingAccountDeletions.records)
        {
            if (!CanRecoverPendingAccountDeletion(record))
            {
                continue;
            }

            Debug.LogWarning("Account deletion recovery available: " + record.accountID + " | Classroom: " + record.classroomID);
        }
    }

    public void CheckPendingDeletionsForActiveClassroom()
    {
        if (DatabaseManager.Instance == null)
            return;

        string classroomID = DatabaseManager.Instance.CurrentDatabase;

        if (string.IsNullOrWhiteSpace(classroomID) || classroomID == "DefaultDatabase")
        {
            return;
        }

        if (deletingAccount)
            return;

        if (pendingAccountDeletions == null ||
            pendingAccountDeletions.records == null)
        {
            return;
        }

        Debug.Log("Checking pending account deletions for classroom: " + classroomID);

        CheckRecoverableAccountDeletions();
    }

    public async Task RecoverPendingAccountDeletions()
    {
        if (deletingAccount ||
            synchronizingPendingAccounts ||
            synchronizingAssignments ||
            loginInProgress ||
            resettingPassword ||
            pendingAccountDeletions == null ||
            pendingAccountDeletions.records == null ||
            pendingAccountDeletions.records.Count == 0)
        {
            return;
        }

        ProgressManager progressManager = ProgressManager.Instance;

        if (progressManager == null ||
            progressManager.IsAccountDeletionInProgress)
        {
            return;
        }

        // Snapshot records because successful recovery removes them.
        List<PendingAccountDeletionRecord> records =
            new List<PendingAccountDeletionRecord>(
                pendingAccountDeletions.records
            );

        foreach (PendingAccountDeletionRecord record in records)
        {
            if (!CanRecoverPendingAccountDeletion(record))
                continue;

            string classroomID = record.classroomID;
            string accountID = record.accountID;

            deletingAccount = true;
            progressManager.BeginAccountDeletion(accountID);

            try
            {
                Debug.Log(
                    "Resuming interrupted account deletion: " +
                    accountID + " | Classroom: " + classroomID
                );

                // Wait for operations that could conflict with deletion.
                await FirestoreAccountManager.WaitForAccountDownloads();
                await progressManager.WaitForBackgroundOperations();
                await FirestoreAccountManager.WaitForAccountOperations(
                    accountID
                );

                // Confirm classroom identity before destructive operations.
                if (DatabaseManager.Instance == null ||
                    DatabaseManager.Instance.CurrentDatabase != classroomID)
                {
                    throw new System.InvalidOperationException(
                        "Active classroom changed during deletion recovery."
                    );
                }

                // Resume Firestore cleanup using the stored classroom ID.
                await FirestoreAccountManager.DeleteAccountProgress(
                    accountID,
                    classroomID: classroomID
                );

                await FirestoreAccountManager.DeleteAccount(
                    accountID,
                    classroomID
                );

                // A cloud operation can take time. Never touch local files
                // unless this is still the selected classroom.
                if (DatabaseManager.Instance == null ||
                    DatabaseManager.Instance.CurrentDatabase != classroomID)
                {
                    throw new System.InvalidOperationException(
                        "Classroom changed during deletion recovery; local cleanup deferred."
                    );
                }

                // Remove local progress.
                string saveFile = Path.Combine(
                    Application.persistentDataPath,
                    "progress_" + accountID + ".json"
                );

                // Older accounts may use non-unique numeric IDs across
                // classrooms. Never delete their shared local progress file
                // during automated recovery without proven ownership.
                System.Guid uniqueAccountID;
                if (System.Guid.TryParse(accountID, out uniqueAccountID))
                {
                    if (File.Exists(saveFile))
                        File.Delete(saveFile);
                }
                else
                {
                    Debug.LogWarning(
                        "Recovery preserved legacy local progress file for " +
                        accountID + ": classroom ownership cannot be verified."
                    );
                }

                // Remove the account from the local registry.
                registry.accounts.RemoveAll(
                    account => account.id == accountID
                );

                // Remove pending account creation.
                pendingAccountUploads.accountIDs.Remove(accountID);
                SavePendingAccountUploads();

                // Remove pending assignment updates for the deleted account.
                pendingAssignmentUploads.accountIDs.Remove(accountID);
                SavePendingAssignmentUploads();

                // Remove the deleted student from teacher assignments.
                foreach (AccountData account in registry.accounts)
                {
                    if (account.accountType == AccountType.Teacher &&
                        account.assignedStudentIDs != null &&
                        account.assignedStudentIDs.Remove(accountID))
                    {
                        // Persist the queue, but don't launch sync until
                        // the deletion guard has been released.
                        if (!pendingAssignmentUploads.accountIDs.Contains(account.id))
                            pendingAssignmentUploads.accountIDs.Add(account.id);
                    }
                }
                SavePendingAssignmentUploads();

                // Clear active account state if necessary.
                if (CurrentAccount.ActiveAccount != null &&
                    CurrentAccount.ActiveAccount.id == accountID)
                {
                    progressManager.ClearDeletedAccountState(accountID);
                    CurrentAccount.ActiveAccount = null;
                }

                if (selectedAccount != null &&
                    selectedAccount.id == accountID)
                {
                    selectedAccount = null;
                    selectedCard = null;
                }

                SaveAccount();

                // Only clear the recovery record after cleanup succeeds.
                ClearAccountPendingDeletion(classroomID, accountID);

                Debug.Log(
                    "Interrupted account deletion recovered successfully: " +
                    accountID
                );
            }
            catch (System.Exception ex)
            {
                Debug.LogError(
                    "Account deletion recovery failed for " +
                    accountID +
                    ". Pending deletion record retained for retry. " +
                    "Error: " + ex
                );
            }
            finally
            {
                progressManager.EndAccountDeletion(accountID);
                deletingAccount = false;
            }
        }

        RefreshUI();

        // The recovery guard is now released for all records.
        if (pendingAssignmentUploads.accountIDs.Count > 0)
            _ = SynchronizePendingAssignments();
    }

    private void SavePendingAccountDeletions()
    {
        string json = JsonUtility.ToJson(pendingAccountDeletions, true);

        File.WriteAllText(pendingDeletionsPath, json);
    }

    public bool IsAccountPendingDeletion(string accountID)
    {
        if (string.IsNullOrWhiteSpace(accountID))
            return false;

        // Legacy records remain blocked until safely resolved.
        if (pendingAccountDeletions.accountIDs != null &&
            pendingAccountDeletions.accountIDs.Contains(accountID))
        {
            return true;
        }

        if (pendingAccountDeletions.records == null)
        {
            return false;
        }

        string classroomID = DatabaseManager.Instance != null ? DatabaseManager.Instance.CurrentDatabase : null;

        // If the Classroom is unknown, block any matching
        // pending account rather than risk activating it.
        return pendingAccountDeletions.records.Exists(record => record != null && record.accountID == accountID &&
            (string.IsNullOrWhiteSpace(classroomID) ||
            record.classroomID == classroomID)
        );
    }

    private void MarkAccountPendingDeletion(string classroomID, string accountID)
    {
        if (string.IsNullOrWhiteSpace(classroomID) || string.IsNullOrWhiteSpace(accountID))
        {
            throw new System.ArgumentException("Cannot register pending deletion without " + "a Classroom ID and Account ID.");
        }

        if (pendingAccountDeletions.records == null)
        {
            pendingAccountDeletions.records = new List<PendingAccountDeletionRecord>();
        }

        bool alreadyPending =
            pendingAccountDeletions.records.Exists(record => record != null && record.classroomID == classroomID && record.accountID == accountID);

        if (alreadyPending)
        {
            return;
        }

        PendingAccountDeletionRecord newRecord = new PendingAccountDeletionRecord
        {
            classroomID = classroomID,
            accountID = accountID
        };

        pendingAccountDeletions.records.Add(newRecord);

        try
        {
            SavePendingAccountDeletions();

            Debug.Log("Account marked for pending deletion: " + accountID + " | Classroom: " + classroomID
            );
        }

        catch
        {
            pendingAccountDeletions.records.Remove(newRecord);
            throw;
        }
    }

    private void ClearAccountPendingDeletion(string classroomID, string accountID)
    {
        if (string.IsNullOrWhiteSpace(classroomID) || string.IsNullOrWhiteSpace(accountID))
        {
            return;
        }

        if (pendingAccountDeletions.records == null)
        {
            return;
        }

        List<PendingAccountDeletionRecord> removedRecords =
            pendingAccountDeletions.records.FindAll(
                record => record != null && record.classroomID == classroomID && record.accountID == accountID
            );

        if (removedRecords.Count == 0)
        {
            return;
        }

        pendingAccountDeletions.records.RemoveAll(
            record => record != null && record.classroomID == classroomID && record.accountID == accountID
        );

        try
        {
            SavePendingAccountDeletions();

            Debug.Log("Pending account deletion cleared: " + accountID + " | Classroom: " + classroomID);
        }

        catch (System.Exception ex)
        {
            pendingAccountDeletions.records.AddRange(removedRecords);

            Debug.LogError(
                "Failed to clear pending account deletion: " + ex
            );

            throw;
        }
    }

    private void SavePendingAssignmentUploads()
    {
        string json = JsonUtility.ToJson(
            pendingAssignmentUploads, true
        );

        File.WriteAllText(pendingAssignmentsPath, json);
    }

    public bool IsAssignmentPendingUpload(string accountID)
    {
        return pendingAssignmentUploads.accountIDs.Contains(accountID);
    }

    public void QueueAssignmentUpload(string teacherID)
    {
        if (!pendingAssignmentUploads.accountIDs.Contains(teacherID))
        {
            pendingAssignmentUploads.accountIDs.Add(teacherID);
            SavePendingAssignmentUploads();
        }

        _ = SynchronizePendingAssignments();
    }

    public async Task SynchronizePendingAssignments()
    {
        if (deletingAccount || (ProgressManager.Instance != null && ProgressManager.Instance.IsAccountDeletionInProgress))
        {
            Debug.LogWarning("Pending assignment synchronization blocked: Account deletion is in progress.");
            return;
        }

        if (synchronizingAssignments)
            return;

        if (pendingAssignmentUploads.accountIDs.Count == 0)
            return;

        if (FirestoreManager.Instance == null)
            return;

        synchronizingAssignments = true;

        try
        {
            List<string> pendingIDs = new List<string>(
                pendingAssignmentUploads.accountIDs
            );

            foreach (string teacherID in pendingIDs)
            {
                AccountData teacher = registry.accounts.Find(
                    a => a.id == teacherID
                );

                if (teacher == null)
                    continue;

                if (DatabaseManager.Instance == null ||
                teacher.classroomID != DatabaseManager.Instance.CurrentDatabase)
                {
                    continue;
                }

                // An account still awaiting its initial creation upload
                // will be handled by the existing account queue.
                if (IsAccountPendingUpload(teacherID))
                    continue;

                try
                {
                    List<string> assignmentSnapshot =
                        new List<string>(teacher.assignedStudentIDs);

                    await FirestoreAccountManager.UploadAssignments(
                        teacherID,
                        assignmentSnapshot
                    );

                    bool verified =
                        await FirestoreAccountManager.VerifyAssignments(
                            teacherID,
                            assignmentSnapshot
                        );

                    if (!verified)
                        continue;

                    // Don't clear the pending entry if the user changed
                    // assignments while this upload was in progress.
                    if (!new HashSet<string>(teacher.assignedStudentIDs)
                        .SetEquals(assignmentSnapshot))
                    {
                        continue;
                    }

                    pendingAssignmentUploads.accountIDs.Remove(teacherID);
                    SavePendingAssignmentUploads();

                    Debug.Log(
                        "Teacher assignments synchronized: " +
                        teacher.username
                    );
                }
                catch (System.Exception ex)
                {
                    Debug.LogWarning(
                        "Assignment sync pending for " +
                        teacher.username + ": " + ex.Message
                    );
                }
            }
        }
        finally
        {
            synchronizingAssignments = false;
        }
    }

    private void SavePendingAccountUploads()
    {
        string json = JsonUtility.ToJson(pendingAccountUploads, true);
        File.WriteAllText(pendingAccountsPath, json);
    }

    public bool IsAccountPendingUpload(string accountID)
    {
        return pendingAccountUploads.accountIDs.Contains(accountID);
    }

    public async Task SynchronizePendingAccounts()
    {
        if (deletingAccount || (ProgressManager.Instance != null && ProgressManager.Instance.IsAccountDeletionInProgress))
        {
            Debug.LogWarning("Pending account synchronization blocked: Account deletion is in progress.");
            return;
        }

        if (synchronizingPendingAccounts)
            return;

        if (pendingAccountUploads.accountIDs.Count == 0)
            return;

        if (FirestoreManager.Instance == null)
        {
            Debug.LogWarning(
                "Account synchronization skipped: Firestore is not initialized."
            );
            return;
        }

        string synchronizationClassroomID = DatabaseManager.Instance != null
        ? DatabaseManager.Instance.CurrentDatabase
        : null;

        if (string.IsNullOrWhiteSpace(synchronizationClassroomID) || synchronizationClassroomID == "DefaultDatabase")
        {
            Debug.LogWarning(
                "Pending account synchronization skipped: " +
                "No valid classroom is active."
            );

            return;
        }

        synchronizingPendingAccounts = true;

        try
        {
            // Snapshot the queue so changes do not affect iteration.
            List<string> pendingIDs =
                new List<string>(pendingAccountUploads.accountIDs);

            foreach (string accountID in pendingIDs)
            {
                if (DatabaseManager.Instance == null || DatabaseManager.Instance.CurrentDatabase != synchronizationClassroomID)
                {
                    Debug.LogWarning(
                        "Pending account synchronization stopped: " +
                        "The active classroom changed."
                    );

                    break;
                }

                AccountData account = registry.accounts.Find(
                    a => a.id == accountID
                );

                if (account == null)
                {
                    Debug.LogWarning(
                        "Pending account not found locally: " + accountID
                    );

                    // Keep the pending ID for investigation.
                    continue;
                }

                // Never upload an account into a different classroom.
                if (account.classroomID != synchronizationClassroomID)
                {
                    Debug.LogWarning(
                        "Pending account upload skipped: Classroom mismatch.\n" +
                        "Account: " + account.username + "\n" +
                        "Account Classroom: " + account.classroomID + "\n" +
                        "Active Classroom: " + synchronizationClassroomID
                    );

                    // Keep the pending record for its original classroom.
                    continue;
                }

                if (IsAccountPendingDeletion(accountID))
                {
                    Debug.LogWarning(
                        "Skipping pending account upload because deletion is pending: " +
                        accountID
                    );

                    continue;
                }

                try
                {
                    await FirestoreAccountManager.UploadAccount(account);

                    // Verify that the account exists on the server.
                    bool uploaded = await FirestoreAccountManager.IsAccountUploaded(accountID);

                    if (!uploaded)
                    {
                        Debug.LogWarning(
                            "Account upload not yet confirmed by Firestore: " +
                            account.username
                        );

                        continue;
                    }

                    if (DatabaseManager.Instance == null || DatabaseManager.Instance.CurrentDatabase != synchronizationClassroomID)
                    {
                        Debug.LogWarning(
                            "Account upload completed, but the classroom changed. " +
                            "Keeping the pending upload record: " + accountID
                        );

                        break;
                    }

                    if (IsAccountPendingDeletion(accountID))
                    {
                        Debug.LogWarning(
                            "Account upload completed, but deletion is now pending: " +
                            accountID
                        );

                        continue;
                    }

                    // Remove only after Firestore confirms the upload.
                    pendingAccountUploads.accountIDs.Remove(accountID);
                    SavePendingAccountUploads();

                    Debug.Log(
                        "Pending account synchronized: " + account.username
                    );
                }
                catch (System.Exception ex)
                {
                    Debug.LogWarning(
                        "Account synchronization failed for " +
                        account.username + ": " + ex.Message
                    );

                    // Preserve the pending entry for the next attempt.
                }
            }
        }
        finally
        {
            synchronizingPendingAccounts = false;
        }
    }

    private async Task SynchronizeAccountMenuAsync()
    {
        if (isAccountMenuSynchronizing)
            return;

        if (DatabaseManager.Instance == null ||
            string.IsNullOrWhiteSpace(DatabaseManager.Instance.CurrentDatabase))
        {
            Debug.LogWarning(
                "[Account Menu Sync] No active classroom."
            );
            return;
        }

        isAccountMenuSynchronizing = true;

        try
        {
            Debug.Log("[Account Menu Sync] Starting synchronization.");

            // 1. Accounts and pending account changes.
            if (FirestoreAccountManager.Instance != null)
            {
                await FirestoreAccountManager.Instance.DownloadAccounts();
            }

            // 2. Progress for the currently active account.
            if (ProgressManager.Instance != null &&
                ProgressManager.Instance.HasActiveAccount)
            {
                await ProgressManager.Instance.LoadProgressForActiveAccount();
            }

            // 3. Quiz Packages for the active classroom.
            QuizPackageDownloadManager quizManager =
                FindFirstObjectByType<QuizPackageDownloadManager>(
                    FindObjectsInactive.Include
                );

            if (quizManager != null)
            {
                await quizManager.SyncActiveClassroomPackagesAsync();
            }
            else
            {
                Debug.LogWarning(
                    "[Account Menu Sync] Quiz Package Download Manager not found."
                );
            }

            RefreshUI();

            Debug.Log("[Account Menu Sync] Synchronization finished.");
        }
        catch (System.Exception ex)
        {
            Debug.LogError(
                "[Account Menu Sync] Synchronization failed: " + ex
            );
        }
        finally
        {
            isAccountMenuSynchronizing = false;
        }
    }

    public void ConnectUI(AccountUIReferences ui)
    {
        accountButton = ui.accountButton;
        backButton = ui.backButton;

        accountSelectPanel = ui.accountSelectPanel;
        accountManagementPanel = ui.accountManagementPanel;
        createAccountPanel = ui.createAccountPanel;

        teacherInfoPanel = ui.teacherInfoPanel;
        studentInfoPanel = ui.studentInfoPanel;

        classroomPanel = ui.classroomPanel;

        classroomSelectionPanel = ui.classroomSelectionPanel;
        classroomCreationPanel = ui.classroomCreationPanel;
        classroomNameInput = ui.classroomNameInput;

        mainMenu = ui.mainMenu;

        classroomPanel = ui.classroomPanel;

        assignStudentsButton = ui.assignStudentsButton;
        confirmAssignButton = ui.confirmAssignButton;

        studentContainer = ui.studentContainer;
        teacherContainer = ui.teacherContainer;
        assignedStudentContainer = ui.assignedStudentContainer;

        usernameInputField = ui.usernameInputField;
        passwordInputField = ui.passwordInputField;

        teacherNameText = ui.teacherNameText;
        teacherSectionText = ui.teacherSectionText;
        teacherProgressText = ui.teacherProgressText;
        teacherMetricsText = ui.teacherMetricsText;

        completedLevelsText = ui.completedLevelsText;
        quizStatsText = ui.quizStatsText;

        loginPanel = ui.loginPanel;
        loginPasswordInput = ui.loginPasswordInput;
        loginUsernameText = ui.loginUsernameText;

        // Recovery Code Display
        accountRecoveryDisplay = ui.accountRecoveryDisplay;
        recoveryCodeText = ui.recoveryCodeText;
        confirmRecoveryCodeButton = ui.confirmRecoveryCodeButton;

        // Account Recovery Panel
        accountRecoveryPanel = ui.accountRecoveryPanel;
        accountRecoveryButton = ui.accountRecoveryButton;
        cancelAccountRecoveryButton = ui.cancelAccountRecoveryButton;
        recoveryCodeInputField = ui.recoveryCodeInputField;
        newPasswordInputField = ui.newPasswordInputField;
        confirmPasswordInputField = ui.confirmPasswordInputField;
        confirmAccountRecoveryButton = ui.confirmAccountRecoveryButton;

        cardDeck = ui.cardDeck;

        confirmAccountRecoveryButton.onClick.RemoveAllListeners();
        confirmAccountRecoveryButton.onClick.AddListener(ConfirmAccountRecovery);


        // Accounts Button
        Button accountBtn = accountButton.GetComponent<Button>();

        accountBtn.onClick.RemoveAllListeners();

        accountBtn.onClick.AddListener(OpenAccountMenu);


        // Back Button
        Button backBtn = backButton.GetComponent<Button>();

        backBtn.onClick.RemoveAllListeners();

        backBtn.onClick.AddListener(CloseAccountMenu);

        // Open Account Recovery
        accountRecoveryButton.onClick.RemoveAllListeners();
        accountRecoveryButton.onClick.AddListener(OpenAccountRecovery);

        // Cancel Account Recovery
        cancelAccountRecoveryButton.onClick.RemoveAllListeners();
        cancelAccountRecoveryButton.onClick.AddListener(CancelAccountRecovery);

        // Create Student Button
        Button createStudentBtn = ui.createStudentButton.GetComponent<Button>();

        createStudentBtn.onClick.RemoveAllListeners();

        createStudentBtn.onClick.AddListener(OpenCreateStudentMenu);


        // Create Teacher Button
        Button createTeacherBtn =
            ui.createTeacherButton.GetComponent<Button>();

        createTeacherBtn.onClick.RemoveAllListeners();

        createTeacherBtn.onClick.AddListener(OpenCreateTeacherMenu);


        // Submit Username Button
        Button submitBtn =
            ui.submitUsernameButton.GetComponent<Button>();

        submitBtn.onClick.RemoveAllListeners();

        submitBtn.onClick.AddListener(SubmitUsername);

        // Confirm Recovery Code Button
        confirmRecoveryCodeButton.onClick.RemoveAllListeners();

        confirmRecoveryCodeButton.onClick.AddListener(ConfirmRecoveryCode);


        // Delete Account Button
        Button deleteBtn =
            ui.deleteAccountButton.GetComponent<Button>();

        deleteBtn.onClick.RemoveAllListeners();

        deleteBtn.onClick.AddListener(DeleteSelected);


        // Assign Students Button
        Button assignBtn =
            assignStudentsButton.GetComponent<Button>();

        assignBtn.onClick.RemoveAllListeners();

        assignBtn.onClick.AddListener(StartAssignStudents);


        // Confirm Assign Button
        Button confirmBtn =
            confirmAssignButton.GetComponent<Button>();

        confirmBtn.onClick.RemoveAllListeners();

        confirmBtn.onClick.AddListener(ConfirmAssignStudents);

        //Confirm Login Button
        Button loginBtn =
            ui.confirmLoginButton.GetComponent<Button>();

        loginBtn.onClick.RemoveAllListeners();

        loginBtn.onClick.AddListener(ConfirmLogin);

        //Cancel Login Button
        Button cancelBtn =
            ui.cancelLoginButton.GetComponent<Button>();

        cancelBtn.onClick.RemoveAllListeners();

        cancelBtn.onClick.AddListener(CancelLogin);

        LoadAccount();

        HideAllPanels();

        accountButton.SetActive(true);

        backButton.SetActive(false);

        RefreshUI();

        Debug.Log("UI Connected Successfully");
    }

    private static string HashPassword(string password)
    {
        SHA256 sha = SHA256.Create();

        byte[] bytes = sha.ComputeHash(Encoding.UTF8.GetBytes(password));

        StringBuilder builder = new StringBuilder();

        foreach (byte b in bytes)
        {
            builder.Append(b.ToString("x2"));
        }

        return builder.ToString();

    }

    private static string GenerateRecoveryCode()
    {
        const string characters = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";

        byte[] randomBytes = new byte[24];

        using (RandomNumberGenerator rng = RandomNumberGenerator.Create())
        {
            rng.GetBytes(randomBytes);
        }

        StringBuilder code = new StringBuilder();

        for (int i = 0; i < randomBytes.Length; i++)
        {
            if (i > 0 && i % 4 == 0)
            {
                code.Append("-");
            }

            code.Append(characters[randomBytes[i] % characters.Length]);
        }

        return code.ToString();
    }

    private static string HashRecoveryCode(string code)
    {
        using (SHA256 sha = SHA256.Create())
        {
            byte[] bytes = sha.ComputeHash(
                Encoding.UTF8.GetBytes(code)
            );

            StringBuilder builder = new StringBuilder();

            foreach (byte b in bytes)
            {
                builder.Append(b.ToString("x2"));
            }

            return builder.ToString();
        }
    }

    private void EnsureAccountsFileExists()
    {
        if (!File.Exists(registryPath))
        {
            registry = new AccountRegistry();

            SaveAccount();

            Debug.Log("accounts.json created");
        }
    }

    // Update is called once per frame
    void Update()
    {
        if (studentInfoPanel == null || !studentInfoPanel.activeInHierarchy)
            return;

        if (Mouse.current == null ||
            !Mouse.current.leftButton.wasPressedThisFrame)
            return;

        if (EventSystem.current == null)
            return;

        // Check which UI elements were clicked.
        PointerEventData pointerData =
            new PointerEventData(EventSystem.current);

        pointerData.position = Mouse.current.position.ReadValue();

        List<RaycastResult> results = new List<RaycastResult>();

        EventSystem.current.RaycastAll(pointerData, results);

        foreach (RaycastResult result in results)
        {
            // Ignore clicks on scrollable UI controls.
            if (result.gameObject.GetComponentInParent<ScrollRect>() != null &&
                result.gameObject.transform.IsChildOf(studentInfoPanel.transform))
            {
                return;
            }
        }

        CloseStudentInfo();
    }

}

[System.Serializable]
public class PendingAccountUploads
{
    public List<string> accountIDs = new List<string>();
}

[System.Serializable]
public class PendingAccountDeletionRecord
{
    public string classroomID;
    public string accountID;
}

[System.Serializable]
public class PendingAccountDeletions
{
    // Legacy records retained for migration.
    public List<string> accountIDs = new List<string>();

    // New classroom-aware deletion records.
    public List<PendingAccountDeletionRecord> records = new List<PendingAccountDeletionRecord>();
}