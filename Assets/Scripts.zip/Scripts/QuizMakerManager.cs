using Firebase.Firestore;
using SFB;
using System.IO;
using TMPro;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.UI;
using static UnityEngine.Rendering.ReloadAttribute;

public class QuizMakerManager : MonoBehaviour
{
    [Header("UI")]
    public GameObject QuizMakerPanel;
    public GameObject backButton;
    public GameObject accountButton;
    public GameObject mainMenuImage;
    public GameObject waitSyncPanel;
    public GameObject syncInputBlocker;
    public GameObject title;

    [Header("Feedback")]
    public QuizMakerFeedback feedback;

    [Header("Quiz Selection")]
    public GameObject currentQuizPanel;
    public TMP_Text currentQuizText;

    [Header("New Quiz")]
    public GameObject nameQuizPanel;
    public TMP_InputField quizNameInputField;

    [Header("Question")]
    public TMP_InputField quizQuestionInputField;

    public TMP_Dropdown questionTypeDropdown;
    public TMP_Dropdown inputTypeDropdown;

    [Header("Question Type Panels")]
    public GameObject identificationPanel;
    public GameObject multipleChoicePanel;
    public GameObject trueFalsePanel;

    [Header("Media Button")]
    public GameObject imageButton;
    public GameObject audioButton;

    [Header("Multiple Choice")]
    public TMP_InputField AnswerA;
    public TMP_InputField AnswerB;
    public TMP_InputField AnswerC;
    public TMP_InputField AnswerD;

    [Header("Identification")]
    public TMP_InputField identificationAnswer;

    [Header("Multiple Choice Correct Answer Buttons")]
    public Image[] correctAnswerButtons;

    [Header("True or False Buttons")]
    public Image trueButtonImage;
    public Image falseButtonImage;

    [Header("Remove Question Panel")]
    public GameObject removeQuestionPanel;

    [Header("Remove Quiz Confirmation")]
    public GameObject removeQuizConfirmationPanel;

    public Transform questionGridContent;

    public GameObject multipleChoiceQuestionTemplate;
    public GameObject trueFalseQuestionTemplate;

    private System.Collections.Generic.List<int> selectedQuestion = new System.Collections.Generic.List<int>();

    private bool trueFalseAnswer = true;
    private int correctAnswerIndex = 0;
    private bool[] multipleSelectAnswers = new bool[4];
    private int SelectedQuestionType => questionTypeDropdown.value - 1;

    private int SelectedInputType => inputTypeDropdown.value - 1;

    private bool isClosingQuizMaker = false;
    private bool isDeletingQuiz = false;
    public bool IsDeletingQuiz => isDeletingQuiz;

    private string selectedImagePath;
    private string selectedAudioPath;

    private string selectedQuizPath;

    public static string SelectedQuizName = null;
    public static string SelectedQuizFilePath = null;
    public string SelectedQuizPath => selectedQuizPath;

    public static string QuizPackagesRoot
    {
        get
        {
            #if UNITY_EDITOR
                        return Path.Combine(
                            Directory.GetParent(Application.dataPath).FullName,
                            "QuizPackages"
                        );
            #else
                    return Path.Combine(
                        Application.persistentDataPath,
                        "QuizPackages"
                    );
            #endif
                    }
                }

    public void OpenQuizMakerPanel()
    {
        // Reset synchronization UI when opening Quiz Maker.
        if (waitSyncPanel != null)
        {
            waitSyncPanel.SetActive(false);
        }

        // Ensure Quiz Maker controls are usable when opening.
        if (syncInputBlocker != null)
        {
            syncInputBlocker.SetActive(false);
        }

        QuizMakerPanel.SetActive(true);
        accountButton.SetActive(false);
        backButton.SetActive(true);

        Button backButtonComponent = backButton.GetComponent<Button>();

        if (backButtonComponent != null)
        {
            backButtonComponent.interactable = true;
        }

        mainMenuImage.SetActive(false);

        if (title != null)
        {
            title.SetActive(false);
        }
    }

    public void OpenNewQuizPanel()
    {
        nameQuizPanel.SetActive(true);
        quizNameInputField.text = "";
    }

    public void CancelNewQuiz()
    {
        nameQuizPanel.SetActive(false);
    }
    
    public void CancelRemoveQuestion()
    {
        selectedQuestion.Clear();

        removeQuestionPanel.SetActive(false);
    }

    public async void CloseQuizMakerPanel()
    {
        if (MainMenu.IsOptionsMenuOpen)
        {
            return;
        }

        if (QuizMakerPanel == null || !QuizMakerPanel.activeSelf)
        {
            return;
        }

        // Prevent the player from triggering another exit
        // while an upload is already running.
        if (isClosingQuizMaker || isDeletingQuiz)
        {
            return;
        }

        isClosingQuizMaker = true;

        // Keep Back visible, but prevent additional clicks.
        Button backButtonComponent = backButton.GetComponent<Button>();

        if (backButtonComponent != null)
        {
            backButtonComponent.interactable = false;
        }

        // Prevent interactions with Quiz Maker while synchronizing.
        if (syncInputBlocker != null)
        {
            syncInputBlocker.SetActive(true);
        }

        // Show the synchronization panel.
        if (waitSyncPanel != null)
        {
            waitSyncPanel.SetActive(true);
        }

        try
        {
            string selectedQuizPath = SelectedQuizFilePath;

            if (!string.IsNullOrWhiteSpace(selectedQuizPath))
            {
                QuizPackageUploadManager uploadManager =
                    FindFirstObjectByType<QuizPackageUploadManager>();

                if (uploadManager != null)
                {
                    bool success =
                        await uploadManager.UploadSelectedPackageAsync();

                    if (!success)
                    {
                        Debug.LogWarning(
                            "[Quiz Maker] Automatic upload was unsuccessful. " +
                            "Local Quiz Package files were preserved."
                        );
                    }
                }

                else
                {
                    Debug.LogWarning(
                        "[Quiz Maker] QuizPackageUploadManager not found. " +
                        "Automatic upload skipped."
                    );
                }
            }

            QuizMakerPanel.SetActive(false);

            accountButton.SetActive(true);
            backButton.SetActive(false);
            mainMenuImage.SetActive(true);

            if (title != null)
            {
                title.SetActive(true);
            }

            if (syncInputBlocker != null)
            {
                syncInputBlocker.SetActive(false);
            }
        }

        catch (System.Exception ex)
        {
            Debug.LogError(
                "[Quiz Maker] Error while closing Quiz Maker: " + ex
            );
        }

        finally
        {
            // Always remove synchronization UI,
            // even if an unexpected error occurs.
            if (waitSyncPanel != null)
            {
                waitSyncPanel.SetActive(false);
            }

            if (syncInputBlocker != null)
            {
                syncInputBlocker.SetActive(false);
            }

            // Restore Back button interaction if Quiz Maker
            // remains open because synchronization failed.
            if (QuizMakerPanel != null && QuizMakerPanel.activeSelf)
            {
                if (backButton != null)
                {
                    backButton.SetActive(true);

                    Button BackButtonComponent =
                        backButton.GetComponent<Button>();

                    if (BackButtonComponent != null)
                        BackButtonComponent.interactable = true;
                }
            }

            isClosingQuizMaker = false;
        }
    }


    public void ConfirmNewQuiz()
    {
        string quizName = quizNameInputField.text.Trim();

        if (string.IsNullOrEmpty(quizName))
        {
            ShowQuizMakerFeedback("Quiz Name is Empty");
            return;
        }

        // Prevent invalid folder and file names.
        if (quizName.IndexOfAny(Path.GetInvalidFileNameChars()) >= 0 ||quizName == "." || quizName == "..")
        {
            ShowQuizMakerFeedback("Quiz name contains invalid characters.");
            return;
        }


        // Every Quiz Package belongs to the active Classroom.
        string classroomID =DatabaseManager.Instance != null ? DatabaseManager.Instance.CurrentDatabase : null;

        if (string.IsNullOrWhiteSpace(classroomID) ||
            classroomID == "DefaultDatabase")
        {
            ShowQuizMakerFeedback("Select a Classroom before creating a Quiz Package.");
            return;
        }

        // Root directory for this Classroom's Quiz Packages.
        string quizRoot = Path.Combine(
            QuizPackagesRoot,
            classroomID
        );

        // Each Quiz Package gets its own folder.
        string packageFolder = Path.Combine(
            quizRoot,
            quizName
        );

        string imagesFolder = Path.Combine(packageFolder, "Images");
        string soundsFolder = Path.Combine(packageFolder, "Sounds");

        string quizFilePath = Path.Combine(packageFolder,quizName + ".txt");

        string infoFilePath = Path.Combine(packageFolder,quizName + "_info.txt");

        try
        {
            // Don't accidentally reuse or overwrite an existing package.
            if (Directory.Exists(packageFolder))
            {
                ShowQuizMakerFeedback("A Quiz Package with this name already exists: " + quizName);
                {
                    return;
                }
            }

            Directory.CreateDirectory(packageFolder);
            Directory.CreateDirectory(imagesFolder);
            Directory.CreateDirectory(soundsFolder);

            // Create the question and Quiz Info files.
            File.WriteAllText(quizFilePath, "");
            File.WriteAllText(infoFilePath, "");

            // Select the newly created quiz.
            SelectQuiz(quizFilePath);

            nameQuizPanel.SetActive(false);

            Debug.Log("Successfully created Quiz Package: " +packageFolder);
        }

        catch (System.Exception ex)
        {
            ShowQuizMakerFeedback("Failed to create the Quiz Package. Please try again.");
        }
    }

    public void OpenRemoveQuizConfirmation()
    {
        if (string.IsNullOrWhiteSpace(selectedQuizPath))
        {
            ShowQuizMakerFeedback("No Quiz selected for deletion. Please select a Quiz Package before deleting it");
            return;
        }

        string quizName =
            Path.GetFileNameWithoutExtension(selectedQuizPath);

        if (string.Equals(
            quizName,
            "questions",
            System.StringComparison.OrdinalIgnoreCase))
        {
            ShowQuizMakerFeedback("Default Questions file cannot be deleted.");
            return;
        }

        removeQuizConfirmationPanel.SetActive(true);
    }

    public void CancelRemoveQuizConfirmation()
    {
        removeQuizConfirmationPanel.SetActive(false);
    }

    public async void ConfirmRemoveQuiz()
    {
        if (isDeletingQuiz || isClosingQuizMaker)
            return;

        if (string.IsNullOrWhiteSpace(selectedQuizPath))
            return;

        string originalPath = selectedQuizPath;
        string packageID = Path.GetFileNameWithoutExtension(originalPath);

        if (string.Equals(packageID, "questions", System.StringComparison.OrdinalIgnoreCase))
        {
            ShowQuizMakerFeedback("Default Questions.txt cannot be deleted.");
            return;
        }

        string classroomID = DatabaseManager.Instance != null ? DatabaseManager.Instance.CurrentDatabase : null;

        if (string.IsNullOrWhiteSpace(classroomID) || classroomID == "DefaultDatabase")
        {
            ShowQuizMakerFeedback("Select a Classroom before deleting a Quiz Package.");
            return;
        }

        // Only allow deletion of a package inside the active Classroom.
        string expectedFolder = Path.GetFullPath(
            Path.Combine(
                QuizPackagesRoot,
                classroomID,
                packageID
            )
        );

        string actualFolder = Path.GetFullPath(
            Path.GetDirectoryName(originalPath)
        );

        string expectedQuizFile = Path.Combine(
            expectedFolder,
            packageID + ".txt"
        );

        if (!string.Equals(
            actualFolder,
            expectedFolder,
            System.StringComparison.OrdinalIgnoreCase) ||
            !string.Equals(
                Path.GetFullPath(originalPath),
                Path.GetFullPath(expectedQuizFile),
                System.StringComparison.OrdinalIgnoreCase))
        {
            ShowQuizMakerFeedback("This Quiz Package cannot be deleted from the current Classroom.");
            return;
        }

        if (!Directory.Exists(expectedFolder) || !File.Exists(expectedQuizFile))
        {
            ShowQuizMakerFeedback("The Quiz Package files could not be found.");
            return;
        }

        QuizPackageUploadManager uploadManager = FindFirstObjectByType<QuizPackageUploadManager>();

        if (uploadManager == null)
        {
            ShowQuizMakerFeedback("Unable to delete the Quiz Package. Please try again later.");
            return;
        }

        if (uploadManager.IsUploading)
        {
            ShowQuizMakerFeedback("Please wait for the current upload to finish before deleting a Quiz Package.");
            return;
        }

        isDeletingQuiz = true;

        try
        { 
            bool alreadyDeleted =
                await uploadManager.IsPackageDeletionConfirmedAsync(
                    classroomID,
                    packageID
                );

            if (alreadyDeleted)
            {
                Debug.Log(
                    "Quiz Package was already marked deleted in Firestore. " +
                    "Retrying local cleanup: " + packageID
                );
            }

            QuizPackageSyncData sync =
                QuizPackageSyncManager.Load(classroomID, packageID);

            if (alreadyDeleted)
            {
                // Firestore already confirmed deletion.
                // Continue to local cleanup without another cloud write.
            }
            else if (sync != null &&
                     !string.IsNullOrWhiteSpace(sync.baseVersionID))
            {
                if (uploadManager == null)
                {
                    Debug.LogError(
                        "Deletion blocked: Upload Manager not found."
                    );
                    return;
                }

                // This method verifies that the published version
                // still matches our local synchronization baseline.
                bool markedDeleted =
                    await uploadManager.MarkPackageDeletedAsync(packageID);

                if (!markedDeleted)
                {
                    Debug.LogWarning("Deletion cancelled: Firestore did not confirm deletion.");
                    ShowQuizMakerFeedback("The Quiz Package could not be deleted. Please try again.");

                    return;
                }
            }

            else
            {
                // A package without synchronization metadata may be
                // local-only. Verify and reserve its deletion in Firestore.
                if (uploadManager == null)
                {
                    Debug.LogError(
                        "Deletion blocked: Upload Manager not found."
                    );
                    return;
                }

                bool markedDeleted =
                    await uploadManager.MarkLocalOnlyPackageDeletedAsync(
                        classroomID,
                        packageID
                    );

                if (!markedDeleted)
                {
                    Debug.LogWarning("Deletion cancelled: Firestore could not confirm " +"that this is a local-only Quiz Package.");
                    ShowQuizMakerFeedback("The Quiz Package could not be deleted. Please try again.");
                    return;
                }

                Debug.Log(
                    "Local-only Quiz Package deletion authorized: " +
                    packageID
                );
            }

            // The Classroom-wide deletion has been acknowledged.
            // Remove the entire local package, including media and Quiz Info.

            if (DatabaseManager.Instance == null ||
                DatabaseManager.Instance.CurrentDatabase != classroomID ||
                selectedQuizPath != originalPath ||
                SelectedQuizFilePath != originalPath)
            {
                Debug.LogWarning("Local deletion cancelled: The active Classroom " +"or selected Quiz Package changed during deletion.");
                ShowQuizMakerFeedback("The Classroom or selected Quiz Package changed. Please try again.");
                return;
            }


            Directory.Delete(expectedFolder, true);

            if (!QuizPackageSyncManager.Delete(classroomID, packageID))
            {
                Debug.LogWarning("Quiz Package deleted, but local synchronization " + "metadata could not be removed.");
                ShowQuizMakerFeedback("Quiz Package deleted, but its local synchronization data could not be cleared.");
            }

            if (selectedQuizPath == originalPath)
                DeselectQuiz();

            removeQuizConfirmationPanel.SetActive(false);

            Debug.Log(
                "Quiz Package deleted locally and marked deleted in Firestore: " +
                packageID
            );
        }

        catch (System.Exception ex)
        {
            Debug.LogError("Quiz Package deletion failed: " + ex);
            ShowQuizMakerFeedback("An error occurred while deleting the Quiz Package.");
        }

        finally
        {
            isDeletingQuiz = false;
        }
    }

    public void RemoveQuiz()
    {
        if (string.IsNullOrEmpty(selectedQuizPath))
        {
            ShowQuizMakerFeedback("No Quiz Selected");
            return;
        }

        string fileName = Path.GetFileNameWithoutExtension(selectedQuizPath);

        // Don't allow the default quiz to be deleted
        if (fileName.ToLower() == "questions")
        {
            ShowQuizMakerFeedback("Questions.txt cannot be deleted.");
            return;
        }

        if (File.Exists(selectedQuizPath))
        {
            File.Delete(selectedQuizPath);
        }

        selectedQuizPath = null;
        SelectedQuizName = null;
        SelectedQuizFilePath = null;

        currentQuizText.text = "No quiz selected";

        Debug.Log("Quiz deleted: " + fileName);
    }

    public void ConfirmRemoveQuestion()
    {
        if(selectedQuestion.Count == 0)
        {
            ShowQuizMakerFeedback("No questions selected for deletion");
            return;
        }

        if (string.IsNullOrEmpty(selectedQuizPath))
        {
            ShowQuizMakerFeedback("Selected Quiz File Does Not Exist");
            return;
        }

        string[] lines = File.ReadAllLines(selectedQuizPath);

        System.Collections.Generic.List<string> newLines = new System.Collections.Generic.List<string>();

        int questionsIndex = 0;
        int i = 0;

        while (i < lines.Length)
        {
            //Skip Blank Lines
            if (string.IsNullOrWhiteSpace(lines[i]))
            {
                i++;
                continue;
            }

            //Check if ID line, if not, skip
            if (!lines[i].StartsWith("ID:"))
            {
                i++;
                continue;
            }

            //Find End of Question
            int questionstart = i;

            i++;

            //Question
            i++;

            //Question Type
            i++;

            //Input Type
            string inputType = lines[i].Trim();
            i++;

            if (inputType.StartsWith("INPUT:TRUE_OR_FALSE"))
            {
                //True or False only has one Answer line
                i++;
            }

            else
            {
                //Multiple Choice & Identification have four Answer lines
                i += 4;
            }

            int quesetionend = i;

            //Keep this question if not selected
            if (!selectedQuestion.Contains(questionsIndex))
            {
                for(int j = questionstart; j < quesetionend; j++)
                {
                    newLines.Add(lines[j]);
                }

                //Add Spaces between questions
                newLines.Add("");
            }

            questionsIndex++;
        }

        //Renumber the remaning questions
        int newQuestionNumber = 1;

        for (int j = 0; j < newLines.Count; j++)
        {
            if (newLines[j].StartsWith("ID:"))
            {
                //Change Old ID
                string oldID = newLines[j].Substring(3).Trim();

                string quizName = Path.GetFileNameWithoutExtension(selectedQuizPath).ToUpper();

                newLines[j] = "ID:" + quizName + newQuestionNumber;

                //Change question number
                if(j + 1 < newLines.Count)
                {
                    string questionText = newLines[j + 1];

                    int dotIndex = questionText.IndexOf(".");

                    if(dotIndex != -1)
                    {
                        string actualQuestion = questionText.Substring(dotIndex + 1).Trim();

                        newLines[j + 1] = newQuestionNumber + ". " + actualQuestion;
                    }
                }

                newQuestionNumber++;
            }
        }

        File.WriteAllLines(selectedQuizPath, newLines);

        Debug.Log("Deleted " + selectedQuestion.Count + " question(s).");

        selectedQuestion.Clear();

        removeQuestionPanel.SetActive(false);

        RefreshRemoveQuestionPanel();
    }


    public void OpenFileExplorer()
    {
        string classroomID =
            DatabaseManager.Instance != null
                ? DatabaseManager.Instance.CurrentDatabase
                : null;

        if (string.IsNullOrWhiteSpace(classroomID) ||
            classroomID == "DefaultDatabase")
        {
            Debug.LogWarning(
                "Select a Classroom before choosing a Quiz Package."
            );
            return;
        }

        string folderPath = Path.Combine(
            QuizPackagesRoot,
            classroomID
        );

        if (!Directory.Exists(folderPath))
        {
            Directory.CreateDirectory(folderPath);
        }

        Debug.Log("Opening Quiz File Explorer");
        Debug.Log("Starting Folder: " + folderPath);

        ExtensionFilter[] extensions =
        {
        new ExtensionFilter("Quiz Files", "txt")
    };

        string[] paths = StandaloneFileBrowser.OpenFilePanel(
            "Select Quiz",
            folderPath,
            extensions,
            false
        );

        Debug.Log("Number of paths returned: " + paths.Length);

        if (paths.Length > 0)
        {
            Debug.Log("Selected file path: " + paths[0]);

            SelectQuiz(paths[0]);
        }
        else
        {
            Debug.LogWarning("No file was selected.");
        }
    }

    public void OpenImageFileExplorer()
    {
        if (string.IsNullOrEmpty(selectedQuizPath) ||
            !File.Exists(selectedQuizPath))
        {
            Debug.LogWarning("Select a quiz before adding an image.");
            return;
        }

        ExtensionFilter[] extensions =
        {
        new ExtensionFilter("Image Files", "png", "jpg", "jpeg")
    };

        string[] paths = StandaloneFileBrowser.OpenFilePanel(
            "Select Image",
            "",
            extensions,
            false
        );

        if (paths.Length == 0 || string.IsNullOrEmpty(paths[0]))
            return;

        try
        {
            string packageFolder = Path.GetDirectoryName(selectedQuizPath);
            string imagesFolder = Path.Combine(packageFolder, "Images");

            Directory.CreateDirectory(imagesFolder);

            string fileName = Path.GetFileName(paths[0]);
            string destination = Path.Combine(imagesFolder, fileName);

            if (Path.GetFullPath(paths[0]) != Path.GetFullPath(destination))
            {
                File.Copy(paths[0], destination, true);
            }

            selectedImagePath = "Images/" + fileName;

            Debug.Log("Image added to Quiz Package: " + selectedImagePath);
        }
        catch (System.Exception ex)
        {
            Debug.LogError("Failed to import image: " + ex.Message);
        }
    }

    public void OpenAudioFileExplorer()
    {
        if (string.IsNullOrEmpty(selectedQuizPath) || !File.Exists(selectedQuizPath))
        {
            Debug.LogWarning("Select a quiz before adding audio.");
            return;
        }

        ExtensionFilter[] extensions =
        {
        new ExtensionFilter("Audio Files", "mp3", "wav", "ogg")
        };

        string[] paths = StandaloneFileBrowser.OpenFilePanel("Select Audio", "", extensions, false);

        if (paths.Length == 0 || string.IsNullOrEmpty(paths[0]))
            return;

        try
        {
            string packageFolder = Path.GetDirectoryName(selectedQuizPath);
            string soundsFolder = Path.Combine(packageFolder, "Sounds");

            Directory.CreateDirectory(soundsFolder);

            string fileName = Path.GetFileName(paths[0]);
            string destination = Path.Combine(soundsFolder, fileName);

            if (Path.GetFullPath(paths[0]) != Path.GetFullPath(destination))
            {
                File.Copy(paths[0], destination, true);
            }

            selectedAudioPath = "Sounds/" + fileName;

            Debug.Log("Audio added to Quiz Package: " + selectedAudioPath);
        }
        catch (System.Exception ex)
        {
            Debug.LogError("Failed to import audio: " + ex.Message);
        }
    }

    public void OpenRemoveQuestionPanel()
    {
        Debug.Log("Remove Question using quiz: " + selectedQuizPath);
        
        removeQuestionPanel.SetActive(true);

        RefreshRemoveQuestionPanel();
    }

    public void SelectQuiz(string path)
    {
        selectedQuizPath = path;

        string fileName = Path.GetFileNameWithoutExtension(path);

        currentQuizText.text = fileName;

        SelectedQuizName = fileName;
        SelectedQuizFilePath = path;

        Debug.Log("Selected Quiz:" + fileName);
    }

    public void DeselectQuiz()
    {
        selectedQuizPath = null;

        SelectedQuizName = null;
        SelectedQuizFilePath = null;

        if (currentQuizText != null)
        {
            currentQuizText.text = "No quiz selected";
        }

        Debug.Log("Quiz deselected. Campaign quiz files will be used.");
    }

    public void OnInputTypeChanged()
    {
        Debug.Log("Input Type: " + inputTypeDropdown.value);
        identificationPanel.SetActive(false);
        multipleChoicePanel.SetActive(false);
        trueFalsePanel.SetActive(false);

        switch (SelectedInputType)
        {
            case 0: //Identification
                identificationPanel.SetActive(true);
                break;

            case 1: //Multiple Choice
                multipleChoicePanel.SetActive(true);
                break;

            case 2: //True or False
                trueFalsePanel.SetActive(true);
                break;

            case 3: //Multiple Select
                multipleChoicePanel.SetActive(true);
                break;

            case 4: // Fill in the Blank
                identificationPanel.SetActive(true);
                break;
        }

        // Reset answer selections when changing input types.
        correctAnswerIndex = 0;
        multipleSelectAnswers = new bool[4];

        UpdateCorrectAnswerButtons();
    }
    public void OnQuestionTypeChanged()
    {
        Debug.Log("Question Type:" + questionTypeDropdown.value);

        imageButton.SetActive(false);
        audioButton.SetActive(false);

        switch (SelectedQuestionType)
        {
            case 0: //Text
                break;

            case 1: //Image
                imageButton.SetActive(true);
                break;

            case 2: //Audio
                audioButton.SetActive(true);
                break;
        }
    }

    private string BuildQuestionEntry(string id, int number)
    {
        string entry = "";

        //ID
        entry += "ID:" + id + "\n";
        
        //Question
        entry += number + ". " + quizQuestionInputField.text.Trim() + "\n";

        //Question Types
        switch (SelectedQuestionType)
        {
            case 0:
                entry += "TYPE:TEXT\n";
                break;

            case 1:
                entry += "TYPE:IMAGE:" + selectedImagePath + "\n";
                break;

            case 2:
                entry += "TYPE:AUDIO:" + selectedAudioPath + "\n";
                break;
        }

        //Input Types
        switch (SelectedInputType)
        {
            case 0: //Indentification
                entry += "INPUT:IDENTIFICATION\n";

                entry += "A. " + identificationAnswer.text.Trim() + " \"C\"\n";
                entry += "B.\n";
                entry += "C.\n";
                entry += "D.\n";
                break;

            case 1: //Multiple Choice
                entry += "INPUT:MULTIPLE_CHOICE\n";

                string[] answers =
                {
                    AnswerA.text.Trim(),
                    AnswerB.text.Trim(),
                    AnswerC.text.Trim(),
                    AnswerD.text.Trim(),
                };

                char letter = 'A';

                for(int i = 0; i < answers.Length; i++)
                {
                    entry += letter + ". " + answers[i];
                    if(i == correctAnswerIndex)
                    {
                        entry += " \"C\"";
                    }

                    entry += "\n";
                    letter++;
                }
                break;

            case 2: //True or False
                entry += "INPUT:TRUE_OR_FALSE\n";

                entry += "ANSWER:" + (trueFalseAnswer ? "TRUE" : "FALSE") + "\n";
                break;

            case 3: // Multiple Select
                entry += "INPUT:MULTIPLE_SELECT\n";

                string[] selectAnswers =
                {
                    AnswerA.text.Trim(),
                    AnswerB.text.Trim(),
                    AnswerC.text.Trim(),
                    AnswerD.text.Trim()
                };

                for (int i = 0; i < selectAnswers.Length; i++)
                {
                    char answerLetter = (char)('A' + i);

                    entry += answerLetter + ". " + selectAnswers[i];

                    if (multipleSelectAnswers[i])
                    {
                        entry += " \"C\"";
                    }

                    entry += "\n";
                }
                break;

            case 4: // Fill in the Blank
                entry += "INPUT:FILL_IN_THE_BLANK\n";

                entry += "A. " + identificationAnswer.text.Trim() + " \"C\"\n";
                entry += "B.\n";
                entry += "C.\n";
                entry += "D.\n";
                break;
        }

        entry += "\n";

        return entry;
    }

    public void SetCorrectAnswer(int index)
    {
        if (index < 0 || index >= correctAnswerButtons.Length || index >= multipleSelectAnswers.Length)
        {
            Debug.LogWarning("Invalid correct answer index: " + index);
            return;
        }

        if (SelectedInputType == 3) // Multiple Select
        {
            // Toggle the selected answer independently.
            multipleSelectAnswers[index] = !multipleSelectAnswers[index];

            Debug.Log("Multiple Select Answer " + index + ": " + multipleSelectAnswers[index]);
        }

        else // Multiple Choice
        {
            // Only one correct answer.
            correctAnswerIndex = index;

            Debug.Log("Correct Answer Set To: " + index);
        }

        UpdateCorrectAnswerButtons();
    }

    private void UpdateCorrectAnswerButtons()
    {
        for (int i = 0; i < correctAnswerButtons.Length; i++)
        {
            if (correctAnswerButtons[i] == null)
            {
                continue;
            }

            bool isCorrect;

            if (SelectedInputType == 3) // Multiple Select
            {
                isCorrect = i < multipleSelectAnswers.Length && multipleSelectAnswers[i];
            }

            else // Multiple Choice
            {
                isCorrect = i == correctAnswerIndex;
            }

            correctAnswerButtons[i].color = isCorrect ? Color.green : Color.white;
        }
    }

    public void SetTrueAnswer()
    {
        Debug.Log("True Selected");

        trueFalseAnswer = true;

        trueButtonImage.color = Color.green;
        falseButtonImage.color = Color.red;
    }

    public void SetFalseAnswer()
    {
        Debug.Log("False Selected");

        trueFalseAnswer = false;

        falseButtonImage.color = Color.green;
        trueButtonImage.color = Color.red;
    }

    public void AddQuestion()
    {
        //Validate Quiz file is selected
        if (string.IsNullOrEmpty(SelectedQuizPath))
        {
            ShowQuizMakerFeedback("Please select a quiz first.");
            return;
        }

        //Validate Quiz file exists
        if (!File.Exists(selectedQuizPath))
        {
            ShowQuizMakerFeedback("The selected quiz file could not be found.");
            return;
        }

        string question = quizQuestionInputField.text.Trim();

        //Check if Question is empty or null
        if (string.IsNullOrEmpty(question))
        {
            ShowQuizMakerFeedback("Please enter a question.");
            return;
        }

        if (questionTypeDropdown.value == 0 || inputTypeDropdown.value == 0)
        {
            ShowQuizMakerFeedback("Please select both a Question Type and an Input Type.");
            return;
        }

        switch (SelectedInputType)
        {
            case 0: //Identification
                if (string.IsNullOrEmpty(identificationAnswer.text.Trim()))
                {
                    ShowQuizMakerFeedback("Please provide an identification answer.");
                    return;
                }

                break;

            case 1: // Multiple Choice

                if (string.IsNullOrEmpty(AnswerA.text.Trim()) ||
                    string.IsNullOrEmpty(AnswerB.text.Trim()) ||
                    string.IsNullOrEmpty(AnswerC.text.Trim()) ||
                    string.IsNullOrEmpty(AnswerD.text.Trim()))
                {
                    ShowQuizMakerFeedback("Please fill in all four multiple-choice answers.");
                    return;
                }

                break;

            case 2: // True or False
                break;

            case 3: // Multiple Select

                // All four answers must be filled.
                if (string.IsNullOrWhiteSpace(AnswerA.text) ||
                    string.IsNullOrWhiteSpace(AnswerB.text) ||
                    string.IsNullOrWhiteSpace(AnswerC.text) ||
                    string.IsNullOrWhiteSpace(AnswerD.text))
                {
                    ShowQuizMakerFeedback("Please fill in all four multiple-select answers.");
                    return;
                }

                // Require at least two correct answers.
                int correctCount = 0;

                foreach (bool isCorrect in multipleSelectAnswers)
                {
                    if (isCorrect)
                    {
                        correctCount++;
                    }
                }

                if (correctCount < 2)
                {
                    ShowQuizMakerFeedback("Multiple Select requires at least two correct answers.");

                    return;
                }
                break;

            case 4: // Fill in the Blank
                if (string.IsNullOrWhiteSpace(identificationAnswer.text))
                {
                    ShowQuizMakerFeedback("Please provide the correct answer for the Fill in the Blank question.");
                    return;
                }

                int blankCount = question.Split(new string[] { "____" }, System.StringSplitOptions.None).Length - 1;

                if (blankCount != 1)
                {
                    ShowQuizMakerFeedback("Fill in the Blank requires exactly one '____' placeholder in the question.");
                    return;
                }

                break;
        }

        int questionCount = 0;

        string[] lines = File.ReadAllLines(selectedQuizPath);

        foreach(string line in lines)
        {
            if (line.StartsWith("ID:"))
            {
                questionCount++;
            }
        }

        //Question Number is the next following number
        int questionNumber = questionCount + 1;

        //ID line is QuizName + ID Number together
        string quizName = Path.GetFileNameWithoutExtension(selectedQuizPath).ToUpper();
        string id = quizName + questionNumber;

        //Build the Question based on the format
        string entry = BuildQuestionEntry(id, questionNumber);

        //separeate previous question from new question
        if (new FileInfo(selectedQuizPath).Length > 0)
        {
            File.AppendAllText(selectedQuizPath, "");
        }

        //Add question to the file
        File.AppendAllText(selectedQuizPath, entry);
        ClearQuestionFields();
    }

    private void ShowQuizMakerFeedback(string message)
    {
        Debug.LogWarning(message);

        if (feedback != null)
        {
            feedback.ShowFeedback(message);
        }
    }


    private class RemoveQuestionData
    {
        public string id;
        public string question;
        public string questionType;
        public string inputType;

        public string answerA;
        public string answerB;
        public string answerC;
        public string answerD;

        public string trueFalseAnswer;
    }

    private System.Collections.Generic.List<RemoveQuestionData> ParseQuestionsForRemoval()
    {
        System.Collections.Generic.List<RemoveQuestionData> result = new System.Collections.Generic.List<RemoveQuestionData>();

        if (string.IsNullOrEmpty(selectedQuizPath))
        {
            return result;
        }

        if (!File.Exists(selectedQuizPath))
        {
            return result;
        }

        string[] lines = File.ReadAllLines(selectedQuizPath);

        int i = 0;

        while (i < lines.Length)
        {
            // Skip blank lines
            if (string.IsNullOrWhiteSpace(lines[i]))
            {
                i++;
                continue;
            }

            // Every question must begin with ID:
            if (!lines[i].StartsWith("ID:"))
            {
                i++;
                continue;
            }

            RemoveQuestionData data = new RemoveQuestionData();

            //ID
            data.id = lines[i].Trim();
            i++;

            //Question
            data.question = lines[i].Trim();

            int dotIndex = data.question.IndexOf(".");

            if (dotIndex != -1)
            {
                data.question =
                    data.question.Substring(dotIndex + 1).Trim();
            }

            i++;

            //QUestion Type
            data.questionType = lines[i].Trim();
            i++;

            //Input Type
            data.inputType = lines[i].Trim();
            i++;

            //True or False
            if (data.inputType.StartsWith("INPUT:TRUE_OR_FALSE"))
            {
                data.trueFalseAnswer = lines[i].Trim();

                i++;
            }
            else
            {

                //A
                data.answerA = lines[i].Trim();
                i++;

                //B
                data.answerB = lines[i].Trim();
                i++;

                //C
                data.answerC = lines[i].Trim();
                i++;

                //D
                data.answerD = lines[i].Trim();
                i++;
            }

            result.Add(data);
        }

        return result;
    }


    private void RefreshRemoveQuestionPanel()
    {
        Debug.Log("REFRESH REMOVE QUESTION PANEL");
        Debug.Log("Children before cleanup: " + questionGridContent.childCount);
        Debug.Log("Selected quiz: " + selectedQuizPath);

        //Remove Old Templates
        for (int i = questionGridContent.childCount - 1; i >= 0; i--)
        {
            Destroy(questionGridContent.GetChild(i).gameObject);
        }

        selectedQuestion.Clear();

        System.Collections.Generic.List<RemoveQuestionData> question = ParseQuestionsForRemoval();

        for(int i = 0; i < question.Count; i++)
        {
            RemoveQuestionData data = question[i];

            GameObject template;

            //True or False template
            if (data.inputType.StartsWith("INPUT:TRUE_OR_FALSE"))
            {
                template = trueFalseQuestionTemplate;
            }

            //Multiple Choice / Identification
            else
            {
                template = multipleChoiceQuestionTemplate;
            }

            GameObject questionObject = Instantiate(template, questionGridContent);

            questionObject.SetActive(true);

            QuestionPlaceholderTemplate item = questionObject.GetComponent<QuestionPlaceholderTemplate>();

            item.Setup(
                this,
                i,
                data.id,
                data.question,
                data.questionType,
                data.inputType,
                data.answerA,
                data.answerB,
                data.answerC,
                data.answerD,
                data.trueFalseAnswer
            );
        }
    }

    private void ClearQuestionFields()
    {
        // Clear question text
        quizQuestionInputField.text = "";

        // Clear multiple-choice answers
        AnswerA.text = "";
        AnswerB.text = "";
        AnswerC.text = "";
        AnswerD.text = "";

        // Clear identification answer
        identificationAnswer.text = "";

        // Clear selected image and audio references
        selectedImagePath = null;
        selectedAudioPath = null;

        // Reset answer selections.
        correctAnswerIndex = 0;
        multipleSelectAnswers = new bool[4];

        UpdateCorrectAnswerButtons();
        SetTrueAnswer();

        Debug.Log("Question fields cleared.");
    }

    public void ToggleQuestionSelection(int index, bool selected)
    {
        if (selected)
        {
            if (!selectedQuestion.Contains(index))
            {
                selectedQuestion.Add(index);
            }
        }

        else
        {
            selectedQuestion.Remove(index);
        }

        Debug.Log("Selected Question: " + selectedQuestion.Count);
    }

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        // Restore the previously selected quiz.
        if (!string.IsNullOrEmpty(SelectedQuizFilePath) && File.Exists(SelectedQuizFilePath))
        {
            selectedQuizPath = SelectedQuizFilePath;
            SelectedQuizName = Path.GetFileNameWithoutExtension(selectedQuizPath);

            if (currentQuizText != null)
            {
                currentQuizText.text = SelectedQuizName;
            }
        }

        else
        {
            // Clear invalid or missing selections.
            selectedQuizPath = null;
            SelectedQuizFilePath = null;
            SelectedQuizName = null;

            if (currentQuizText != null)
            {
                currentQuizText.text = "No quiz selected";
            }
        }

        // Start both dropdowns on their placeholder labels.
        questionTypeDropdown.value = 0;
        inputTypeDropdown.value = 0;

        correctAnswerIndex = 0;
        multipleSelectAnswers = new bool[4];

        UpdateCorrectAnswerButtons();
        SetTrueAnswer();
    }

    // Update is called once per frame
    void Update()
    {

    }
}
