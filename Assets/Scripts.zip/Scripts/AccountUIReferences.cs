using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class AccountUIReferences : MonoBehaviour
{
    [Header("Panels")]
    public GameObject accountButton;
    public GameObject backButton;
    public GameObject accountSelectPanel;
    public GameObject accountManagementPanel;
    public GameObject createAccountPanel;
    public GameObject teacherInfoPanel;
    public GameObject studentInfoPanel;
    public GameObject mainMenu;
    public GameObject cardDeck;

    [Header("Account Synchronization")]
    public GameObject waitSyncPanel;
    public GameObject syncInputBlocker;

    [Header("Account Feedback")]
    public QuizMakerFeedback accountFeedback;

    [Header("Teacher Monitoring")]
    public GameObject assignStudentsButton;
    public GameObject confirmAssignButton;

    [Header("Containers")]
    public Transform studentContainer;
    public Transform teacherContainer;
    public Transform assignedStudentContainer;

    [Header("TMP")]
    public TMP_InputField usernameInputField;
    public TMP_InputField passwordInputField;

    public TextMeshProUGUI teacherNameText;
    public TextMeshProUGUI teacherSectionText;
    public TextMeshProUGUI completedLevelsText;
    public TMP_Text teacherProgressText;
    public TMP_Text teacherMetricsText;
    public TextMeshProUGUI quizStatsText;

    [Header("Buttons")]
    public GameObject createStudentButton;

    public GameObject createTeacherButton;

    public GameObject submitUsernameButton;

    public GameObject cancelCreateAccountButton;

    public GameObject deleteAccountButton;

    [Header("Login")]
    public GameObject loginPanel;
    public TMP_InputField loginPasswordInput;
    public TMP_Text loginUsernameText;
    public GameObject confirmLoginButton;
    public GameObject cancelLoginButton;

    [Header("ClassroomPanel")]
    public GameObject classroomPanel;
    public GameObject openClassroomSelectionButton;

    [Header("Classroom Selection")]
    public GameObject classroomSelectionPanel;
    public Transform classroomContainer;
    public GameObject classroomCardPrefab;
    public GameObject openClassroomCreationButton;
    public GameObject cancelClassroomSelectionButton;
    public TMP_Text currentClassroomNameText;

    [Header("Classroom Creation")]
    public GameObject classroomCreationPanel;
    public TMP_InputField classroomNameInput;
    public GameObject confirmCreationButton;
    public GameObject cancelCreationButton;

    [Header("Recovery Code Display")]
    public GameObject accountRecoveryDisplay;
    public TMP_Text recoveryCodeText;
    public Button confirmRecoveryCodeButton;

    [Header("Account Recovery")]
    public GameObject accountRecoveryPanel;
    public Button accountRecoveryButton;
    public Button cancelAccountRecoveryButton;
    public TMP_InputField recoveryCodeInputField;
    public TMP_InputField newPasswordInputField;
    public TMP_InputField confirmPasswordInputField;
    public Button confirmAccountRecoveryButton;


    void Start()
    {
        Debug.Log("AccountUIReference started");

        if (AccountManager.Instance != null)
        {
            Debug.Log("Connecting UI");
            AccountManager.Instance.ConnectUI(this);
        }
        else
        {
            Debug.LogError("AccountManager.Instance is Null");
        }

        if (FirestoreClassroomManager.Instance != null)
        {
            FirestoreClassroomManager.Instance.ConnectUI(this);
            FirestoreClassroomManager.Instance.ConnectClassroomButtons(this);
        }
        else
        {
            Debug.LogError("FirestoreClassroomManager.Instance is Null");
        }
    }
}