using UnityEngine;
using UnityEngine.UI;

public class BackdropHandler : MonoBehaviour
{
    [SerializeField] private Image backdrop;
    public GameObject BackdropObject => backdrop != null ? backdrop.gameObject : null;

    private void OnEnable()
    {
        SetBackdropVisible(true);
    }

    private void OnDisable()
    {
        if (backdrop == null)
        {
            return;
        }

        // Check whether another active BackdropHandler
        // is still using the same background.
        BackdropHandler[] handlers = FindObjectsByType<BackdropHandler>(FindObjectsSortMode.None);

        foreach (BackdropHandler handler in handlers)
        {
            if (handler == this)
            {
                continue;
            }

            if (handler.backdrop == backdrop && handler.isActiveAndEnabled)
            {
                // Another panel still needs this background.
                return;
            }
        }

        SetBackdropVisible(false);
    }

    private void SetBackdropVisible(bool visible)
    {
        if (backdrop == null)
        {
            Debug.LogError("Backdrop image is not assigned.", this);
            return;
        }

        if (visible)
        {
            Color color = backdrop.color;
            color.a = 1f;
            backdrop.color = color;
        }

        backdrop.gameObject.SetActive(visible);
    }
}
