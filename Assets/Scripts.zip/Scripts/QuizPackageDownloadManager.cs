using System;
using System.IO;
using System.Collections.Generic;
using System.Threading.Tasks;
using UnityEngine;
using Firebase.Firestore;

public class QuizPackageDownloadManager : MonoBehaviour
{
    private bool isDownloading = false;
    public bool TryGetQuizCollection(out CollectionReference quizCollection)
    {
        quizCollection = null;

        if (DatabaseManager.Instance == null)
        {
            Debug.LogError(
                "Quiz download: DatabaseManager is missing."
            );
            return false;
        }

        string classroomID =
            DatabaseManager.Instance.CurrentDatabase;

        if (string.IsNullOrWhiteSpace(classroomID) ||
            classroomID == "DefaultDatabase")
        {
            Debug.LogWarning(
                "Quiz download skipped: No active Classroom selected."
            );
            return false;
        }

        if (FirestoreManager.Instance == null ||
            FirestoreManager.Instance.DB == null)
        {
            Debug.LogError(
                "Quiz download: Firestore is not initialized."
            );
            return false;
        }

        if (!FirebaseManager.IsAuthenticated)
        {
            Debug.LogWarning(
                "Quiz download: Firebase authentication is not ready."
            );
            return false;
        }

        quizCollection =
            FirestoreManager.Instance.QuizCollection();

        return true;
    }

    public async Task<List<string>> GetPublishedQuizPackagesAsync()
    {
        List<string> packageIDs = new List<string>();

        if (!TryGetQuizCollection(
            out CollectionReference quizCollection))
        {
            return packageIDs;
        }

        string classroomID =
            DatabaseManager.Instance.CurrentDatabase;

        try
        {
            QuerySnapshot snapshot =
                await quizCollection.GetSnapshotAsync();

            foreach (DocumentSnapshot document in snapshot.Documents)
            {
                // Ignore packages without a published version.
                if (!document.TryGetValue(
                    "activeVersion",
                    out string activeVersion) ||
                    string.IsNullOrWhiteSpace(activeVersion))
                {
                    continue;
                }

                // Only include packages whose active version
                // has finished uploading.
                DocumentSnapshot versionSnapshot =
                    await document.Reference
                        .Collection("versions")
                        .Document(activeVersion)
                        .GetSnapshotAsync();

                if (!versionSnapshot.Exists ||
                    !versionSnapshot.TryGetValue(
                        "status",
                        out string status) ||
                    status != "complete")
                {
                    continue;
                }

                packageIDs.Add(document.Id);

                Debug.Log(
                    "Published Quiz Package found: " +
                    document.Id +
                    " (Version: " + activeVersion + ")"
                );
            }

            // Avoid returning results for a Classroom
            // that is no longer selected.
            if (DatabaseManager.Instance == null ||
                DatabaseManager.Instance.CurrentDatabase != classroomID)
            {
                Debug.LogWarning(
                    "Quiz Package discovery cancelled: " +
                    "Active Classroom changed."
                );

                packageIDs.Clear();
            }

            Debug.Log(
                "Quiz Package discovery finished. " +
                "Published packages found: " +
                packageIDs.Count
            );
        }
        catch (Exception ex)
        {
            Debug.LogError(
                "Failed to discover published Quiz Packages: " + ex
            );

            packageIDs.Clear();
        }

        return packageIDs;
    }

    private string GetQuizPackageRoot()
    {
        return Path.Combine(
            Application.persistentDataPath,
            "Quiz Packages"
        );
    }

    private string GetClassroomFolder(string classroomID)
    {
        return Path.Combine(
            GetQuizPackageRoot(),
            classroomID
        );
    }

    private string GetPackageFolder(
        string classroomID,
        string packageID)
    {
        return Path.Combine(
            GetClassroomFolder(classroomID),
            packageID
        );
    }


    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    [ContextMenu("Test Quiz Package Discovery")]
    public async void TestQuizPackageDiscovery()
    {
        Debug.Log("Starting Quiz Package discovery test...");

        List<string> packages =
            await GetPublishedQuizPackagesAsync();

        foreach (string packageID in packages)
        {
            Debug.Log(
                "[Discovery Test] Available Quiz Package: " +
                packageID
            );
        }

        Debug.Log(
            "[Discovery Test] Total published packages: " +
            packages.Count
        );
    }

}
