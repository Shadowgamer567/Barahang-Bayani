//Handles Enemy Statistics

using System.Collections;
using UnityEngine;

public class EnemyStats : MonoBehaviour
{
    public static event System.Action OnHpLost;
    public static event System.Action OnShieldGained;
    public static event System.Action OnHealed;

    public EnemyTypes enemyType;
    public string DisplayName { get; private set; }
    public GameObject uiObject;
    public EnemyUI ui;
    public EnemyAction[] action => enemyType != null ? enemyType.actions : null;
    private BattleControl battle;

    public Transform uiAnchor;
    public Transform animateChild;
    public Transform visualRoot;
    public GameObject currentModel;
    private CharacterAnimationRelay animationRelay;
    private ActionModifier actionModifier;
    //public GameObject selectionIndicator;

    public int currentHP;
    [SerializeField, Min(1)] private int rolledSpeed = 1;
    public int Speed => rolledSpeed;
    public int MaxSpeed => enemyType != null ? Mathf.Max(1, enemyType.speed) : 1;
    public void RollSpeed() => rolledSpeed = Random.Range(1, MaxSpeed + 1);
    public int shield;
    public int attack;

    [Header("Persistent Effects")]
    [SerializeField] private int bleedValue = 0;

    public int BleedValue => bleedValue;

    private bool isDying = false;
    public bool isDead = false;

    public int PendingActionModifier => actionModifier != null ? actionModifier.PendingModifier : 0;
    private void Start()
    {
        
    }

    void OnEnable()
    {
        if (enemyType == null)
        {
            Debug.LogWarning("EnemyType not assigned yet: " + name);
            return;
        }

        battle = FindFirstObjectByType<BattleControl>();

        currentHP = enemyType.maxHp;
        shield = Mathf.Max(0, enemyType.shield);

        attack = enemyType.damage;
        bleedValue = 0;

        isDying = false;
        isDead = false;

        transform.rotation = Quaternion.identity;

        if(animationRelay != null)
        {
            animationRelay.Play(CharacterAnimationType.Neutral);
        }

        Collider col = GetComponent<Collider>();
        if (col != null)
        {
            col.enabled = true;
        }
    }

    public void InitializeEnemy()
    {
        if (enemyType == null)
        {
            Debug.LogError("EnemyType is NULL");
            return;
        }

        currentHP = enemyType.maxHp;
        DisplayName = enemyType.enemyName;
        shield = Mathf.Max(0, enemyType.shield);
        attack = enemyType.damage;

        bleedValue = 0;

        isDying = false;
        isDead = false;

        actionModifier = GetComponent<ActionModifier>();

        if (actionModifier != null) 
        {
            actionModifier.ClearModifier();
        }

        else
        {
            Debug.LogWarning("ActionModifier missing on enemy: " + name);
        }
    }

    public void SetDisplayName(string value)
    {
        DisplayName = string.IsNullOrWhiteSpace(value) && enemyType != null ? enemyType.enemyName : value;
    }

    void Awake()
    {
        animationRelay = GetComponentInChildren<CharacterAnimationRelay>();
    }

    public void TakeDamage(int amount, bool bypassShield = false)
    {
        if (isDead || isDying || !gameObject.activeInHierarchy)
        {
            return;
        }

        amount = Mathf.Max(0, amount);

        Debug.Log(name + " RECEIVED DAMAGE CALL");

        int previousHP = currentHP;
        int shieldDamage = 0;
        int remainingDamage = amount;

        if (!bypassShield)
        {
            shieldDamage = Mathf.Min(shield, amount);
            shield -= shieldDamage;

            remainingDamage -= shieldDamage;
        }

        if (remainingDamage > 0)
        {
            currentHP -= remainingDamage;
        }

        currentHP = Mathf.Max(currentHP, 0);
        shield = Mathf.Max(shield, 0);

        if (currentHP < previousHP)
        {
            OnHpLost?.Invoke();
        }

        Debug.Log(name + " took " + amount + " damage | Shield Damage: " + shieldDamage + " | HP Damage: " + remainingDamage + " | HP: " + currentHP +
            " | Shield: " + shield
        );

        if (animationRelay != null && currentHP > 0)
        {
            animationRelay.Play(CharacterAnimationType.Damaged);
        }

        if (currentHP <= 0 && !isDying)
        {
            isDead = true;
            Debug.Log(name + " ENTERING DEATH");
            isDying = true;

            foreach (var c in GetComponentsInChildren<Collider>())
            {
                c.enabled = false;
            }

            if (animationRelay != null)
            {
                animationRelay.Play(CharacterAnimationType.Death);
            }

            else
            {
                gameObject.SetActive(false);
            }
        }
    }
    public void TakePiercingDamage(int amount)
    {
        TakeDamage(amount, true);
    }

    public void AddBleed(int amount)
    {
        if (amount <= 0 || isDead || isDying || !gameObject.activeInHierarchy)
        {
            return;
        }

        bleedValue += amount;

        Debug.Log(name + " gained " + amount + " Bleed. Total Bleed: " + bleedValue
        );
    }

    public void ProcessBleed()
    {
        if (bleedValue <= 0 || isDead || isDying || !gameObject.activeInHierarchy)
        {
            return;
        }

        int damage = bleedValue;

        // Bleed bypasses Shield and damages HP directly.
        TakePiercingDamage(damage);

        // Reduce Bleed after dealing damage.
        bleedValue = bleedValue <= 1 ? 0 : Mathf.CeilToInt(bleedValue / 2f);

        Debug.Log(name + " took " + damage + " Bleed Damage. Remaining Bleed: " + bleedValue);
    }


    /*
    void DieImmediate()
    {
        isDying = true;

        Debug.Log(name + " IMMEDIATE DEATH");

        gameObject.SetActive(false);

        if (battle != null)
        {
            battle.OnEnemyKilled();
        }
    }
    */

    public void Heal(int amount)
    {
        if (!gameObject.activeInHierarchy || isDead || currentHP <= 0)
        {
            return;
        }

        amount = Mathf.Max(0, amount);
        int previousHP = currentHP;
        currentHP = Mathf.Min(currentHP + amount, enemyType.maxHp);

        if (currentHP > previousHP)
        {
            OnHealed?.Invoke();
        }

        Debug.Log(name + " healed for: " + amount);
    }

    public void AddShield(int amount)
    {
        if (isDead || isDying || !gameObject.activeInHierarchy)
        {
            return;
        }

        amount = Mathf.Max(0, amount);

        if (amount <= 0)
        {
            return;
        }

        shield += amount;

        OnShieldGained?.Invoke();

        Debug.Log(name + " gained " + amount + " shield | Total Shield: " + shield);
    }

    public void DecayShieldOverflow()
    {
        int maxShield = Mathf.Max(0, enemyType.maxShield);

        if (shield <= maxShield)
        {
            return;
        }

        int overflow = shield - maxShield;
        int remainingOverflow = Mathf.CeilToInt(overflow / 2f);

        shield = maxShield + remainingOverflow;

        Debug.Log(
            name + " shield overflow decayed. " +
            "Remaining Shield: " + shield +
            " | Max Shield: " + maxShield
        );
    }

    /*
    public void BuffAttack(int amount)
    {
        attack += amount;
        Debug.Log(name + " attack increased by " + amount);
    }
    */

    public void AddActionModifier(int amount)
    {
        if (actionModifier != null)
        {
            actionModifier.AddModifier(amount);
        }
    }

    public int GetModifiedActionValue(int baseValue)
    {
        if (actionModifier != null)
        {
            return actionModifier.ConsumedModifier(baseValue);
        }

        return baseValue;
    }
    public void SyncToData(GameData data)
    {
        data.enemy_health = this.currentHP;
    }

    public void LoadModel()
    {
        if (enemyType == null || enemyType.prefab == null)
        {
            Debug.LogWarning("No prefab assigned for enemy: " + name);
            return;
        }

        if (currentModel != null)
        {
            Destroy(currentModel);
        }

        currentModel = Instantiate(enemyType.prefab, visualRoot);
        currentModel.transform.localPosition = enemyType.modelPositionOffset;
        currentModel.transform.localRotation = Quaternion.Euler(enemyType.modelRotationOffset);

        animationRelay = currentModel.GetComponentInChildren<CharacterAnimationRelay>();

        if(animationRelay == null)
        {
            animationRelay = currentModel.AddComponent<CharacterAnimationRelay>();
        }

        FaceHeroes();

        animationRelay.Play(CharacterAnimationType.Neutral);
    }

    void FaceHeroes()
    {
        HeroStats[] heroes = FindObjectsByType<HeroStats>(FindObjectsSortMode.None);

        HeroStats target = null;

        foreach (var h in heroes)
        {
            if (h != null && h.gameObject.activeInHierarchy)
            {
                target = h;
                break;
            }
        }

        if (target == null) return;

        Vector3 direction = (target.transform.position - transform.position).normalized;
        direction.y = 0;

        if (direction != Vector3.zero)
        {
            transform.forward = direction;
        }
    }

    /*public void SetHighlighted(bool state)
    {
        if (selectionIndicator != null)
        {
            selectionIndicator.SetActive(state);
        }
    }*/

    public void PlayAnimation(CharacterAnimationType type)
    {
        if(animationRelay != null)
        {
            animationRelay.Play(type);
        }
    }

    public void OnDeathAnimationComplete()
    {
        if (battle != null)
        {
            battle.OnEnemyKilled();
        }

        gameObject.SetActive(false);
    }
    public bool IsDead()
    {
        return currentHP <= 0;
    }
    

    private void Update()
    {

    }
}
