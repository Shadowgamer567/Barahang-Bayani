using NUnit.Framework;
using UnityEngine;
using System.Collections.Generic;

[CreateAssetMenu(menuName = "Cutscene/CutsceneData")]
public class CutsceneData : ScriptableObject
{
    public List<CutsceneLine> line;
}

public enum SpeakerType
{
    Hero, 
    Enemy,
    Narrator
}

public enum CutscenePose
{
    Idle,
    Talking,
    Thinking,
    Surprised,
    Happy,
    Angry,
    Sad
}

[System.Serializable]
public class CutsceneLine
{
    public string speakerName;
    public SpeakerType speakerType;
    public HeroType hero;
    public EnemyTypes enemy;

    [TextArea(10, 15)]
    public string Dialogue;

    public bool isLeftSide;

    [Header("Character Animation")]
    public CutscenePose pose = CutscenePose.Idle;
}
