using UnityEngine;
using System.IO;
using System.Collections.Generic;
using System.Threading.Tasks;
using UnityEngine.SocialPlatforms;

public class ProgressManager : MonoBehaviour
{
    public static ProgressManager Instance;

    public List<string> completedLevels = new();
    public bool tutorialCompleted = false;

    [Header("Playthrough Tracking")]
    public string playthroughId = "";

    [Header("Lifetime Quiz Statistics")]
    public int multipleChoiceCorrect = 0;
    public int multipleChoiceTotal = 0;

    public int identificationCorrect = 0;
    public int identificationTotal = 0;

    public int trueFalseCorrect = 0;
    public int trueFalseTotal = 0;

    public int multipleSelectCorrect = 0;
    public int multipleSelectTotal = 0;

    public int fillInTheBlankCorrect = 0;
    public int fillInTheBlankTotal = 0;

    [Header("Pending Quiz Synchronization")]
    public List<QuizResultData> pendingQuizResults = new();
    public bool quizResultLedgerInitialized = false;

    [Header("New Game Synchronization")]
    public bool pendingNewGameReset = false;
    public string previousPlaythroughId = "";

    public string lastCampaignScene = "MapMenu";

    private string savePath;
    private AccountData currentAccount;

    public bool HasActiveAccount => currentAccount != null;

    private bool isSyncingQuizResults = false;
    private bool isReconcilingProgress = false;
    private bool isResettingPlaythrough = false;
    private bool isStartingNewGame = false;
    private bool isAutomaticallySynchronizing = false;
    private int progressGeneration = 0;
    private string deletingAccountID = null;

    public bool IsAccountDeletionInProgress => !string.IsNullOrEmpty(deletingAccountID);

    private void Start()
    {

    }

    void Awake()
    {
        if (Instance == null)
        {
            Instance = this;

            DontDestroyOnLoad(gameObject);
        }
        else
        {
            Destroy(gameObject);
        }
    }

    private readonly HashSet<Task> activeBackgroundOperations = new();

    private void TrackBackgroundOperation(Task operation)
    {
        if (operation == null)
        {
            return;
        }

        activeBackgroundOperations.Add(operation);

        _ = ObserveBackgroundOperation(operation);
    }

    private async Task ObserveBackgroundOperation(Task operation)
    {
        try
        {
            await operation;
        }

        catch (System.Exception e)
        {
            Debug.LogError("Background progress operation failed: " + e.Message);
        }

        finally
        {
            activeBackgroundOperations.Remove(operation);
        }
    }

    public async Task WaitForBackgroundOperations()
    {
        while (activeBackgroundOperations.Count > 0)
        {
            Task[] operations = new List<Task>(activeBackgroundOperations).ToArray();

            Debug.Log("Waiting for " + operations.Length + " background progress operation(s) to finish.");

            try
            {
                await Task.WhenAll(operations);
            }

            catch (System.Exception e)
            {
                Debug.LogWarning("A background progress operation ended with an error: " + e.Message);
            }
        }

        Debug.Log("All tracked background progress operations have finished.");
    }

    public bool IsDeletingAccount(string accountID)
    {
        return !string.IsNullOrEmpty(accountID) &&
               deletingAccountID == accountID;
    }

    private bool IsAccountBlockedFromSync(string accountID)
    {
        if (string.IsNullOrWhiteSpace(accountID))
            return false;

        if (IsDeletingAccount(accountID))
            return true;

        return AccountManager.Instance != null &&
               AccountManager.Instance.IsAccountPendingDeletion(accountID);
    }

    public void BeginAccountDeletion(string accountID)
    {
        if (string.IsNullOrWhiteSpace(accountID))
            return;

        deletingAccountID = accountID;

        Debug.Log(
            "Progress synchronization blocked for account deletion: " +
            accountID
        );
    }

    public void EndAccountDeletion(string accountID)
    {
        if (deletingAccountID != accountID)
            return;

        deletingAccountID = null;

        Debug.Log(
            "Account deletion synchronization block cleared: " +
            accountID
        );
    }

    public void ClearDeletedAccountState(string accountID)
    {
        if (string.IsNullOrWhiteSpace(accountID))
            return;

        if (currentAccount == null ||
            currentAccount.id != accountID)
        {
            return;
        }

        // Invalidate the previous account session.
        progressGeneration++;

        // Clear account and save file references.
        currentAccount = null;
        savePath = null;

        // Clear campaign progress.
        completedLevels = new List<string>();
        tutorialCompleted = false;
        lastCampaignScene = "MapMenu";

        // Clear playthrough information.
        playthroughId = "";
        previousPlaythroughId = "";
        pendingNewGameReset = false;

        // Clear quiz synchronization data.
        pendingQuizResults = new List<QuizResultData>();
        quizResultLedgerInitialized = false;

        // Clear lifetime quiz statistics.
        multipleChoiceCorrect = 0;
        multipleChoiceTotal = 0;

        identificationCorrect = 0;
        identificationTotal = 0;

        trueFalseCorrect = 0;
        trueFalseTotal = 0;

        multipleSelectCorrect = 0;
        multipleSelectTotal = 0;

        fillInTheBlankCorrect = 0;
        fillInTheBlankTotal = 0;

        // Clear synchronization flags.
        isSyncingQuizResults = false;
        isReconcilingProgress = false;
        isResettingPlaythrough = false;
        isAutomaticallySynchronizing = false;

        // Clear temporary quiz statistics.
        QuizStats.Instance?.ResetStats();

        Debug.Log(
            "Cleared cached progress state for deleted account: " +
            accountID
        );
    }

    public void ClearActiveAccount()
    {
        progressGeneration++;
        currentAccount = null;
        savePath = string.Empty;
        completedLevels = new List<string>();
        lastCampaignScene = "MapMenu";
        tutorialCompleted = false;
        playthroughId = string.Empty;
        previousPlaythroughId = string.Empty;
        pendingNewGameReset = false;
        pendingQuizResults = new List<QuizResultData>();
        quizResultLedgerInitialized = false;
        QuizStats.Instance?.ResetStats();
    }

    public void SetActiveAccount(AccountData account)
    {
        if (account == null)
        {
            ClearActiveAccount();
            return;
        }

        // Classroom loading can re-select the already active classroom when
        // the Account Menu refreshes. Rebinding the same session must not
        // increment progressGeneration or invalidate an in-flight New Game reset.
        if (currentAccount != null &&
            currentAccount.id == account.id &&
            currentAccount.classroomID == account.classroomID)
        {
            currentAccount = account;
            return;
        }

        progressGeneration++;
        currentAccount = account;

        // Clear temporary statistics from the previous account/level.
        QuizStats.Instance?.ResetStats();

        // Clear lifetime statistics from the previous account.
        // The selected account's saved values will be loaded afterward.
        multipleChoiceCorrect = 0;
        multipleChoiceTotal = 0;

        identificationCorrect = 0;
        identificationTotal = 0;

        trueFalseCorrect = 0;
        trueFalseTotal = 0;

        multipleSelectCorrect = 0;
        multipleSelectTotal = 0;

        fillInTheBlankCorrect = 0;
        fillInTheBlankTotal = 0;

        pendingNewGameReset = false;
        previousPlaythroughId = "";

        savePath = Application.persistentDataPath + "/progress_" + account.id + ".json";

        Debug.Log("Active Save File: " + savePath);

        completedLevels = new List<string>();
        lastCampaignScene = "MapMenu";
        tutorialCompleted = false;
        playthroughId = "";
        pendingQuizResults = new List<QuizResultData>();
        quizResultLedgerInitialized = false;

    }

    public void CompleteLevel(string levelName)
    {
        if (!completedLevels.Contains(levelName))
        {
            completedLevels.Add(levelName);

            SaveProgress();

            Debug.Log("Completed: " + levelName);
        }
    }

    public bool IsLevelCompleted(string levelName)
    {
        return completedLevels.Contains(levelName);
    }


    public void RegisterLifetimeQuestion(InputType type)
    {
        if (currentAccount == null)
            return;

        switch (type)
        {
            case InputType.MultipleChoice:
                multipleChoiceTotal++;
                break;

            case InputType.Identification:
                identificationTotal++;
                break;

            case InputType.TrueOrFalse:
                trueFalseTotal++;
                break;

            case InputType.MultipleSelect:
                multipleSelectTotal++;
                break;

            case InputType.FillInTheBlank:
                fillInTheBlankTotal++;
                break;
        }
    }

    public void RegisterLifetimeCorrect(InputType type)
    {
        if (currentAccount == null)
            return;

        switch (type)
        {
            case InputType.MultipleChoice:
                multipleChoiceCorrect++;
                break;

            case InputType.Identification:
                identificationCorrect++;
                break;

            case InputType.TrueOrFalse:
                trueFalseCorrect++;
                break;

            case InputType.MultipleSelect:
                multipleSelectCorrect++;
                break;

            case InputType.FillInTheBlank:
                fillInTheBlankCorrect++;
                break;
        }
    }


    private bool CanSynchronizeWithCloud()
    {
        GameAuthManager auth = GameAuthManager.Instance;
        return (auth == null || auth.IsOnlineAuthenticated) &&
            Application.internetReachability != NetworkReachability.NotReachable;
    }

    public void SaveProgress(bool uploadToFirestore = true)
    {
        if (IsAccountDeletionInProgress)
        {
            Debug.LogWarning("Progress save skipped: Account deletion in progress.");
            return;
        }

        if (currentAccount == null)
        {
            Debug.LogError("No active account selected!");
            return;
        }

        ProgressData data = new ProgressData();

        data.tutorialCompleted = tutorialCompleted;

        data.username = currentAccount.username;
        data.accountType = currentAccount.accountType.ToString();

        data.completedLevel = completedLevels;
        data.lastCampaignScene = lastCampaignScene;

        data.playthroughId = playthroughId;

        data.pendingNewGameReset = pendingNewGameReset;
        data.previousPlaythroughId = previousPlaythroughId;

        data.pendingQuizResults = new List<QuizResultData>(pendingQuizResults);

        data.quizResultLedgerInitialized = quizResultLedgerInitialized;

        data.multipleChoiceCorrect = multipleChoiceCorrect;
        data.multipleChoiceTotal = multipleChoiceTotal;

        data.identificationCorrect = identificationCorrect;
        data.identificationTotal = identificationTotal;

        data.trueFalseCorrect = trueFalseCorrect;
        data.trueFalseTotal = trueFalseTotal;

        data.multipleSelectCorrect = multipleSelectCorrect;
        data.multipleSelectTotal = multipleSelectTotal;

        data.fillInTheBlankCorrect = fillInTheBlankCorrect;
        data.fillInTheBlankTotal = fillInTheBlankTotal;

        string json = JsonUtility.ToJson(data, true);

        File.WriteAllText(savePath, json);

        if (uploadToFirestore)
        {
            TrackBackgroundOperation(SyncCampaignProgress());
        }

        Debug.Log("Saved Progress For: " + currentAccount.username);
    }

    private async Task SyncCampaignProgress()
    {
        if (!CanSynchronizeWithCloud())
            return; // Local save remains intact; sync can resume online.

        if (IsAccountDeletionInProgress)
        {
            return;
        }

        if (currentAccount == null || pendingNewGameReset || isResettingPlaythrough || string.IsNullOrEmpty(playthroughId))
        {
            return;
        }

        if (currentAccount != null && IsAccountBlockedFromSync(currentAccount.id))
        {
            Debug.LogWarning("Campaign progress synchronization blocked: Account is pending deletion.");
            return;
        }

        string accountId = currentAccount.id;
        string expectedPlaythroughId = playthroughId;
        int operationGeneration = progressGeneration;

        List<string> levelsToUpload = new List<string>(completedLevels);

        bool tutorialToUpload = tutorialCompleted;
        string sceneToUpload = lastCampaignScene;

        try
        {
            bool success =
                await FirestoreProgressManager.UploadCampaignProgress(
                    accountId,
                    expectedPlaythroughId,
                    levelsToUpload,
                    tutorialToUpload,
                    sceneToUpload
                );

            if (currentAccount == null || currentAccount.id != accountId || playthroughId != expectedPlaythroughId ||
                progressGeneration != operationGeneration)
            {
                return;
            }

            if (success)
            {
                Debug.Log(
                    "Campaign progress synchronized successfully."
                );
            }
            else
            {
                Debug.LogWarning(
                    "Campaign progress was not synchronized. " +
                    "Local progress remains saved."
                );
            }
        }
        catch (System.Exception e)
        {
            Debug.LogWarning(
                "Campaign synchronization failed: " + e.Message
            );
        }
    }

    private void MergeLocalCampaignProgress(
        ProgressData localProgress,
        ProgressData cloudProgress)
    {
        if (localProgress == null || cloudProgress == null)
            return;

        // Never merge progress from different playthroughs.
        if (string.IsNullOrEmpty(localProgress.playthroughId) ||
            localProgress.playthroughId != cloudProgress.playthroughId)
        {
            return;
        }

        if (localProgress.completedLevel != null)
        {
            foreach (string level in localProgress.completedLevel)
            {
                if (!completedLevels.Contains(level))
                {
                    completedLevels.Add(level);
                }
            }
        }

        // Tutorial completion should never revert within a playthrough.
        tutorialCompleted |= localProgress.tutorialCompleted;
    }

    public void LoadProgress()
    {
        if (currentAccount == null)
        {
            Debug.LogError("No active account selected!");
            return;
        }

        if (File.Exists(savePath))
        {
            string json = File.ReadAllText(savePath);

            ProgressData data =
                JsonUtility.FromJson<ProgressData>(json);

            ApplyProgress(data);

            Debug.Log("Loaded Progress For: " + currentAccount.username);
        }
        else
        {
            completedLevels = new List<string>();

            lastCampaignScene = "MapMenu";

            SaveProgress(false);

            Debug.Log("Created New Save For: " + currentAccount.username);
        }
    }

    public Task<bool> LoadProgressForActiveAccount()
    {
        if (IsAccountDeletionInProgress)
        {
            Debug.LogWarning("Progress loading blocked: Account deletion is in progress.");

            return Task.FromResult(false);
        }

        Task<bool> operation = LoadProgressForActiveAccountInternal();

        TrackBackgroundOperation(operation);

        return operation;
    }

    public async Task<bool> LoadProgressForActiveAccountInternal()
    {
        if (IsAccountDeletionInProgress)
        {
            Debug.LogWarning("Progress loading skipped: Account deletion in progress.");

            return false;
        }

        if (currentAccount == null)
        {
            Debug.LogError("No active account selected!");
            return false;
        }

        string accountId = currentAccount.id;

        int operationGeneration = progressGeneration;

        // Offline sessions must never call protected cloud endpoints. Load the
        // existing local save and leave pending results queued for later sync.
        if (!CanSynchronizeWithCloud())
        {
            LoadProgress();
            Debug.Log("Loaded local progress for offline gameplay: " + currentAccount.username);
            return true;
        }

        try
        {
            ProgressData cloudProgress = await FirestoreProgressManager.DownloadProgress(accountId);

            if (currentAccount == null ||
                currentAccount.id != accountId ||
                progressGeneration != operationGeneration)
            {
                Debug.LogWarning("Progress loading cancelled: Account session changed.");
                return false;
            }


            ProgressData localProgress = ReadLocalProgress();

            if (localProgress != null &&
                localProgress.pendingNewGameReset &&
                !string.IsNullOrEmpty(localProgress.playthroughId))
            {
                Debug.LogWarning(
                    "Local New Game reset is awaiting Firestore confirmation. " +
                    "Preserving local progress."
                );

                ApplyProgress(localProgress);

                // If connectivity has returned since the reset was created
                // offline, submit the preserved reset to the server now.
                if (CanSynchronizeWithCloud())
                    await RetryPendingNewGameResetInternal();

                StartAutomaticQuizSynchronization();
                return true;
            }


            if (cloudProgress != null)
            {
                //ProgressData localProgress = ReadLocalProgress();

                if (localProgress != null &&
                    !string.IsNullOrEmpty(localProgress.playthroughId) &&
                    localProgress.playthroughId == cloudProgress.playthroughId &&
                    localProgress.pendingQuizResults != null &&
                    localProgress.pendingQuizResults.Count > 0)
                {
                    Debug.LogWarning(
                        "Local unsynchronized quiz results detected. " +
                        "Keeping local progress until safe reconciliation is available."
                    );

                    ApplyProgress(localProgress);

                    // Preserve campaign progress from Firestore as well.
                    if (cloudProgress.completedLevel != null)
                    {
                        foreach (string level in cloudProgress.completedLevel)
                        {
                            if (!completedLevels.Contains(level))
                            {
                                completedLevels.Add(level);
                            }
                        }
                    }

                    tutorialCompleted |= cloudProgress.tutorialCompleted;

                    SaveProgress(false);

                    // Upload the merged campaign progress without touching quiz counters.
                    TrackBackgroundOperation(SyncCampaignProgress());

                    StartAutomaticQuizSynchronization();
                    return true;
                }

                ApplyProgress(cloudProgress);

                // Restore locally completed levels and tutorial progress,
                // but only when both saves belong to the same playthrough.
                MergeLocalCampaignProgress(localProgress, cloudProgress);

                // Preserve locally recorded quiz answers.
                RestorePendingQuizResults(localProgress, cloudProgress);

                // Save the merged progress locally.
                SaveProgress(false);

                // Upload the merged campaign progress to Firestore.
                // Quiz statistics remain managed by their separate synchronization system.
                TrackBackgroundOperation(SyncCampaignProgress());

                StartAutomaticQuizSynchronization();

                Debug.Log("Loaded progress from Firestore and restored local " + "pending results for: " + currentAccount.username);

                return true;
            }
        }
        catch (System.Exception e)
        {
            Debug.LogError("Failed to load progress from Firestore: " + e.Message);
        }

        if (currentAccount == null ||
            currentAccount.id != accountId ||
            progressGeneration != operationGeneration)
        {
            return false;
        }

        LoadProgress();
        StartAutomaticQuizSynchronization();
        return true;
    }

    private void ApplyProgress(ProgressData data)
    {
        completedLevels = data.completedLevel ?? new List<string>();
        lastCampaignScene = string.IsNullOrEmpty(data.lastCampaignScene)
            ? "MapMenu"
            : data.lastCampaignScene;

        playthroughId = data.playthroughId;

        pendingNewGameReset = data.pendingNewGameReset;
        previousPlaythroughId = data.previousPlaythroughId;

        pendingQuizResults = data.pendingQuizResults ?? new List<QuizResultData>();

        quizResultLedgerInitialized = data.quizResultLedgerInitialized;

        multipleChoiceCorrect = data.multipleChoiceCorrect;
        multipleChoiceTotal = data.multipleChoiceTotal;

        identificationCorrect = data.identificationCorrect;
        identificationTotal = data.identificationTotal;

        trueFalseCorrect = data.trueFalseCorrect;
        trueFalseTotal = data.trueFalseTotal;

        multipleSelectCorrect = data.multipleSelectCorrect;
        multipleSelectTotal = data.multipleSelectTotal;

        fillInTheBlankCorrect = data.fillInTheBlankCorrect;
        fillInTheBlankTotal = data.fillInTheBlankTotal;

        tutorialCompleted = data.tutorialCompleted;

        if (tutorialCompleted)
            AchievementManager.Unlock("complete_tutorial");
    }

    /// <summary>
    /// Starts a new playthrough only after the current cloud playthrough has
    /// been loaded and the replacement has been confirmed by Firestore.
    /// </summary>
    public async Task<bool> StartNewGameAndWaitForCloudAsync()
    {
        if (isStartingNewGame)
        {
            Debug.LogWarning("[New Game] A reset workflow is already running.");
            return false;
        }

        isStartingNewGame = true;

        try
        {
            if (!CanSynchronizeWithCloud())
            {
                if (currentAccount == null || IsAccountDeletionInProgress ||
                    isResettingPlaythrough || pendingNewGameReset)
                    return false;

                // Use the locally saved playthrough as the baseline. The reset is
                // marked pending and retained until an online server confirms it.
                LoadProgress();
                NewGame(false);
                return pendingNewGameReset;
            }

            if (currentAccount == null || IsAccountDeletionInProgress ||
                isResettingPlaythrough || pendingNewGameReset)
            {
                Debug.LogWarning("New Game cannot start: account state is not ready.");
                return false;
            }

            // Load the cloud playthrough first so ResetPlaythrough receives the
            // actual previousPlaythroughId for returning players.
            bool loaded = await LoadProgressForActiveAccount();
            if (!loaded || currentAccount == null)
                return false;

            if (pendingNewGameReset)
                return await RetryPendingNewGameResetInternal();

            NewGame(false);
            if (!pendingNewGameReset)
                return false;

            string accountId = currentAccount.id;
            string oldPlaythroughId = previousPlaythroughId;
            string newPlaythroughId = playthroughId;
            int operationGeneration = progressGeneration;

            bool confirmed = await UploadNewGameProgress(
                accountId, oldPlaythroughId, newPlaythroughId, operationGeneration);

            return confirmed && !pendingNewGameReset &&
                currentAccount != null && currentAccount.id == accountId &&
                playthroughId == newPlaythroughId &&
                progressGeneration == operationGeneration;
        }
        finally
        {
            isStartingNewGame = false;
        }
    }

    public void NewGame(bool uploadToFirestore = true)
    {
        if (IsAccountDeletionInProgress)
        {
            Debug.LogWarning(
                "New Game blocked: Account deletion is in progress."
            );

            return;
        }

        if (currentAccount == null)
        {
            Debug.LogError("No active account selected!");
            return;
        }

        if (isResettingPlaythrough)
        {
            Debug.LogWarning(
                "Cannot start New Game while a reset is synchronizing."
            );
            return;
        }

        if (pendingNewGameReset)
        {
            Debug.LogWarning(
                "Cannot start another New Game while the previous reset " +
                "is awaiting Firestore confirmation."
            );
            return;
        }

        progressGeneration++;

        //Remember which playthrough is being replaced
        string accountId = currentAccount.id;
        previousPlaythroughId = playthroughId;

        //Generate New ID for playthrough
        playthroughId = System.Guid.NewGuid().ToString();
        pendingNewGameReset = true;
        string newPlaythroughId = playthroughId;

        // Reset completed levels and tutorial progress.
        completedLevels.Clear();
        tutorialCompleted = false;
        lastCampaignScene = "MapMenu";

        // Reset cumulative quiz metrics.
        multipleChoiceCorrect = 0;
        multipleChoiceTotal = 0;

        identificationCorrect = 0;
        identificationTotal = 0;

        trueFalseCorrect = 0;
        trueFalseTotal = 0;

        multipleSelectCorrect = 0;
        multipleSelectTotal = 0;

        fillInTheBlankCorrect = 0;
        fillInTheBlankTotal = 0;

        // Clear results of previous playthrough
        pendingQuizResults.Clear();

        quizResultLedgerInitialized = true;

        // Reset current-level quiz statistics.
        QuizStats.Instance?.ResetStats();

        // Save the new playthrough's starting progress.
        SaveProgress(false);

        if (uploadToFirestore)
        {
            TrackBackgroundOperation(UploadNewGameProgress(accountId, previousPlaythroughId, newPlaythroughId, progressGeneration));
        }

        Debug.Log("New Game started. New playthrough ID: " + newPlaythroughId);
    }

    private void ConfirmNewGameReset(string accountId, string expectedPlaythroughId, int operationGeneration)
    {
        if (IsDeletingAccount(accountId))
        {
            Debug.LogWarning("New Game confirmation skipped: Account deletion in progress.");

            return;
        }

        if (currentAccount == null ||
            currentAccount.id != accountId ||
            playthroughId != expectedPlaythroughId ||
            progressGeneration != operationGeneration)
        {
            Debug.LogWarning(
                "[New Game] Confirmation ignored because the active session changed. " +
                "Expected Account: " + accountId +
                ", Actual Account: " + (currentAccount != null ? currentAccount.id : "<none>") +
                ", Expected Playthrough: " + expectedPlaythroughId +
                ", Actual Playthrough: " + playthroughId +
                ", Expected Generation: " + operationGeneration +
                ", Actual Generation: " + progressGeneration
            );
            return;
        }

        pendingNewGameReset = false;
        previousPlaythroughId = "";

        SaveProgress(false);

        Debug.Log(
            "New Game reset confirmed and saved locally."
        );
    }

    private async Task<bool> UploadNewGameProgress(
        string accountId,
        string oldPlaythroughId,
        string newPlaythroughId,
        int operationGeneration)
    {
        if (isResettingPlaythrough)
        {
            Debug.LogWarning(
                "New Game upload skipped: Another reset is running."
            );
            return false;
        }

        if (currentAccount == null ||
            currentAccount.id != accountId ||
            playthroughId != newPlaythroughId ||
            progressGeneration != operationGeneration)
        {
            return false;
        }

        isResettingPlaythrough = true;

        try
        {
            ProgressData newProgress = ReadLocalProgress();

            if (newProgress == null ||
                !newProgress.pendingNewGameReset ||
                newProgress.playthroughId != newPlaythroughId)
            {
                Debug.LogWarning(
                    "New Game upload cancelled: Invalid local reset data."
                );
                return false;
            }

            bool success =
                await FirestoreProgressManager.ResetPlaythrough(
                    accountId,
                    newProgress,
                    oldPlaythroughId
                );

            if (success)
            {
                ConfirmNewGameReset(
                    accountId,
                    newPlaythroughId,
                    operationGeneration
                );
                return !pendingNewGameReset;
            }
            else
            {
                Debug.LogWarning(
                    "New Game reset was not confirmed. It remains pending."
                );
                return false;
            }
        }
        catch (System.Exception e)
        {
            Debug.LogWarning(
                "New Game reset upload failed: " + e.Message
            );
            return false;
        }
        finally
        {
            isResettingPlaythrough = false;
        }
    }

    public Task<bool> RetryPendingNewGameReset()
    {
        if (currentAccount != null && IsAccountBlockedFromSync(currentAccount.id))
        {
            Debug.LogWarning(
                "New-game reset retry blocked: Account is pending deletion."
            );

            return Task.FromResult(false);
        }

        if (IsAccountDeletionInProgress)
        {
            Debug.LogWarning("New Game reset recovery blocked: Account deletion is in progress.");

            return Task.FromResult(false);
        }

        Task<bool> operation = RetryPendingNewGameResetInternal();

        TrackBackgroundOperation(operation);

        return operation;
    }

    public async Task<bool> RetryPendingNewGameResetInternal()
    {
        if (IsAccountDeletionInProgress)
        {
            Debug.LogWarning("New Game reset recovery skipped: Account deletion in progress.");
            return false;
        }

        if (isResettingPlaythrough)
        {
            Debug.LogWarning(
                "New Game reset is already being synchronized."
            );
            return false;
        }

        if (currentAccount == null ||
            !pendingNewGameReset ||
            string.IsNullOrEmpty(playthroughId))
        {
            return false;
        }

        isResettingPlaythrough = true;

        string accountId = currentAccount.id;
        string newPlaythroughId = playthroughId;
        string oldPlaythroughId = previousPlaythroughId;
        int operationGeneration = progressGeneration;

        try
        {
            ProgressData data = ReadLocalProgress();

            if (data == null ||
                !data.pendingNewGameReset ||
                data.playthroughId != newPlaythroughId)
            {
                Debug.LogWarning(
                    "New Game retry cancelled: Local reset data is invalid."
                );
                return false;
            }

            bool success =
                await FirestoreProgressManager.ResetPlaythrough(
                    accountId,
                    data,
                    oldPlaythroughId
                );

            if (!success)
            {
                Debug.LogWarning(
                    "New Game retry rejected. Local reset remains pending."
                );
                return false;
            }

            if (currentAccount == null ||
                currentAccount.id != accountId ||
                playthroughId != newPlaythroughId ||
                progressGeneration != operationGeneration)
            {
                Debug.LogWarning(
                    "New Game retry completed, but the active session changed."
                );
                return false;
            }

            ConfirmNewGameReset(
                accountId,
                newPlaythroughId,
                operationGeneration
            );

            Debug.Log("Pending New Game reset successfully recovered.");
            return true;
        }

        catch (System.Exception e)
        {
            Debug.LogWarning(
                "New Game retry failed: " + e.Message
            );

            return false;
        }

        finally
        {
            isResettingPlaythrough = false;
        }
    }

    public async Task<bool> SynchronizeQuizProgress()
    {
        if (!CanSynchronizeWithCloud())
            return false;

        if (currentAccount != null && IsAccountBlockedFromSync(currentAccount.id))
        {
            Debug.LogWarning("Quiz progress synchronization blocked: Account is pending deletion.");
            return false;
        }

        if (IsAccountDeletionInProgress)
        {
            Debug.LogWarning("Quiz synchronization skipped: Account deletion in progress.");
            return false;
        }

        if (currentAccount == null)
        {
            Debug.LogWarning("Automatic synchronization skipped: No active account.");
            return false;
        }

        string accountId = currentAccount.id;
        string activePlaythroughId = playthroughId;
        int operationGeneration = progressGeneration;

        // Step 1: Recover a pending New Game reset.
        if (pendingNewGameReset)
        {
            bool resetRecovered = await RetryPendingNewGameReset();

            if (!resetRecovered)
            {
                Debug.LogWarning(
                    "Automatic synchronization postponed: " +
                    "New Game reset is still pending."
                );
                return false;
            }
        }

        // Step 2: Verify that the account and playthrough
        // are still the same after the awaited operation.
        if (IsDeletingAccount(accountId) ||
            currentAccount == null ||
            currentAccount.id != accountId ||
            playthroughId != activePlaythroughId ||
            progressGeneration != operationGeneration)
        {
            Debug.LogWarning(
                "Automatic synchronization cancelled: Session changed."
            );
            return false;
        }

        if (pendingNewGameReset || isResettingPlaythrough)
        {
            return false;
        }

        if (!quizResultLedgerInitialized ||
            string.IsNullOrEmpty(playthroughId))
        {
            Debug.LogWarning(
                "Automatic synchronization skipped: " +
                "Quiz result ledger is not initialized."
            );
            return false;
        }

        // Step 3: Upload locally saved quiz results.
        await SyncPendingQuizResults();

        // Step 4: Verify the session again.
        if (IsDeletingAccount(accountId) ||
            currentAccount == null ||
            currentAccount.id != accountId ||
            playthroughId != activePlaythroughId ||
            progressGeneration != operationGeneration)
        {
            return false;
        }

        // Step 5: Reconcile local statistics with Firestore.
        bool reconciled = await ReconcileQuizProgress();

        if (reconciled)
        {
            Debug.Log(
                "Automatic quiz synchronization completed successfully."
            );
        }

        return reconciled;
    }

    private void StartAutomaticQuizSynchronization()
    {
        if (currentAccount != null && IsAccountBlockedFromSync(currentAccount.id))
        {
            Debug.LogWarning("Automatic quiz synchronization blocked: Account is pending deletion.");
            return;
        }
        if (IsAccountDeletionInProgress)
        {
            return;
        }

        if (currentAccount == null)
        {
            return;
        }

        if (isAutomaticallySynchronizing)
        {
            return;
        }

        if (string.IsNullOrEmpty(playthroughId))
        {
            return;
        }

        TrackBackgroundOperation(SynchronizeQuizProgress());
    }


    public async void SyncProgressFromFirestore()
    {
        if (currentAccount == null)
        {
            Debug.LogWarning("Cannot synchronize progress: No active account.");
            return;
        }

        try
        {
            bool loaded = await LoadProgressForActiveAccount();

            if (!loaded)
            {
                Debug.LogWarning("Progress synchronization was not completed.");
                return;
            }

            Debug.Log("Progress loaded using the account-safe loading method.");
        }

        catch (System.Exception e)
        {
            Debug.LogError("Progress synchronization failed: " + e.Message);
        }
    }

    public void RecordQuizResult(InputType type, bool isCorrect)
    {
        if (IsAccountDeletionInProgress)
        {
            Debug.LogWarning("Quiz result recording skipped: Account deletion in progress.");
            return;
        }

        if (currentAccount == null)
        {
            return;
        }

        if (string.IsNullOrWhiteSpace(playthroughId))
        {
            Debug.LogWarning("Quiz Result not recorded: No Active Playthrough ID");
            return;
        }

        QuizResultData result = new QuizResultData()
        {
            resultId = System.Guid.NewGuid().ToString(),
            playthroughId = playthroughId,
            questionType = type.ToString(),
            isCorrect = isCorrect
        };

        pendingQuizResults.Add(result);
        SaveProgress(false);

        Debug.Log($"Pending quiz result recorded: {type}, Correct: {isCorrect}");

        // Attempt automatic synchronization after recording an answer.
        // The answer remains saved locally if synchronization fails.
        if (!pendingNewGameReset &&
            !isResettingPlaythrough &&
            !isAutomaticallySynchronizing &&
            !isSyncingQuizResults &&
            !isReconcilingProgress &&
            quizResultLedgerInitialized)
        {
            TrackBackgroundOperation(SynchronizeQuizProgress());
        }
    }

    private ProgressData ReadLocalProgress()
    {
        if (string.IsNullOrEmpty(savePath) || !File.Exists(savePath))
            return null;

        try
        {
            string json = File.ReadAllText(savePath);
            return JsonUtility.FromJson<ProgressData>(json);
        }
        catch (System.Exception e)
        {
            Debug.LogError(
                "Failed to read local progress: " + e.Message);
            return null;
        }
    }

    private void RestorePendingQuizResults(
        ProgressData localProgress,
        ProgressData cloudProgress)
    {
        if (localProgress == null || cloudProgress == null)
            return;

        // Only restore results from the same playthrough.
        if (string.IsNullOrEmpty(localProgress.playthroughId) ||
            localProgress.playthroughId != cloudProgress.playthroughId)
        {
            Debug.Log("Local pending results belong to a different playthrough.");
            return;
        }

        if (localProgress.pendingQuizResults == null)
            return;

        HashSet<string> existingIds = new HashSet<string>();

        foreach (QuizResultData result in pendingQuizResults)
        {
            if (result != null && !string.IsNullOrEmpty(result.resultId))
                existingIds.Add(result.resultId);
        }

        foreach (QuizResultData result in localProgress.pendingQuizResults)
        {
            if (result == null ||
                string.IsNullOrEmpty(result.resultId) ||
                result.playthroughId != cloudProgress.playthroughId)
                continue;

            if (existingIds.Add(result.resultId))
            {
                pendingQuizResults.Add(result);
            }
        }

        Debug.Log(
            "Pending quiz results after local restoration: " + pendingQuizResults.Count);
    }

    private List<QuizResultData> GetValidPendingResults(
        ProgressData localProgress,
        string expectedPlaythroughId)
    {
        List<QuizResultData> validResults =
            new List<QuizResultData>();

        if (localProgress == null ||
            localProgress.pendingQuizResults == null ||
            localProgress.playthroughId != expectedPlaythroughId)
        {
            return validResults;
        }

        HashSet<string> seenIds = new HashSet<string>();

        foreach (QuizResultData result in localProgress.pendingQuizResults)
        {
            if (result == null ||
                string.IsNullOrWhiteSpace(result.resultId) ||
                result.playthroughId != expectedPlaythroughId)
            {
                continue;
            }

            if (seenIds.Add(result.resultId))
            {
                validResults.Add(result);
            }
        }

        return validResults;
    }

    private void AddPendingResultsToCounters(List<QuizResultData> results)
    {
        foreach (QuizResultData result in results)
        {
            if (result == null)
                continue;

            switch (result.questionType)
            {
                case "MultipleChoice":
                    multipleChoiceTotal++;

                    if (result.isCorrect)
                        multipleChoiceCorrect++;

                    break;

                case "Identification":
                    identificationTotal++;

                    if (result.isCorrect)
                        identificationCorrect++;

                    break;

                case "TrueOrFalse":
                    trueFalseTotal++;

                    if (result.isCorrect)
                        trueFalseCorrect++;

                    break;

                case "MultipleSelect":
                    multipleSelectTotal++;

                    if (result.isCorrect)
                        multipleSelectCorrect++;

                    break;

                case "FillInTheBlank":
                    fillInTheBlankTotal++;

                    if (result.isCorrect)
                        fillInTheBlankCorrect++;

                    break;
            }
        }
    }

    private void ApplyCloudQuizCounters(ProgressData cloudProgress)
    {
        if (cloudProgress == null)
            return;

        multipleChoiceCorrect = cloudProgress.multipleChoiceCorrect;
        multipleChoiceTotal = cloudProgress.multipleChoiceTotal;

        identificationCorrect = cloudProgress.identificationCorrect;
        identificationTotal = cloudProgress.identificationTotal;

        trueFalseCorrect = cloudProgress.trueFalseCorrect;
        trueFalseTotal = cloudProgress.trueFalseTotal;

        multipleSelectCorrect = cloudProgress.multipleSelectCorrect;
        multipleSelectTotal = cloudProgress.multipleSelectTotal;

        fillInTheBlankCorrect = cloudProgress.fillInTheBlankCorrect;
        fillInTheBlankTotal = cloudProgress.fillInTheBlankTotal;
    }


    private async Task<List<QuizResultData>> GetUnuploadedPendingResults(
        string accountId,
        string activePlaythroughId,
        List<QuizResultData> validPendingResults)
    {
        HashSet<string> uploadedIds =
            await FirestoreProgressManager.GetUploadedQuizResultIds(
                accountId,
                activePlaythroughId,
                validPendingResults
            );

        List<QuizResultData> unuploadedResults =
            new List<QuizResultData>();

        foreach (QuizResultData result in validPendingResults)
        {
            if (!uploadedIds.Contains(result.resultId))
            {
                unuploadedResults.Add(result);
            }
        }

        return unuploadedResults;
    }

    public Task<bool> ReconcileQuizProgress()
    {
        if (currentAccount != null && IsAccountBlockedFromSync(currentAccount.id))
        {
            Debug.LogWarning(
                "Quiz progress reconciliation blocked: Account is pending deletion."
            );

            return Task.FromResult(false);
        }

        if (IsAccountDeletionInProgress)
        {
            Debug.LogWarning(
                "Quiz reconciliation blocked: Account deletion is in progress."
            );

            return Task.FromResult(false);
        }

        Task<bool> operation = ReconcileQuizProgressInternal();

        TrackBackgroundOperation(operation);

        return operation;
    }

    public async Task<bool> ReconcileQuizProgressInternal()
    {
        if (!CanSynchronizeWithCloud())
            return false;

        if (IsAccountDeletionInProgress)
        {
            Debug.LogWarning("Quiz reconciliation skipped: Account deletion in progress.");
            return false;
        }

        if (isReconcilingProgress || isSyncingQuizResults)
        {
            Debug.LogWarning("Quiz reconciliation skipped: Another operation is running.");
            return false;
        }

        if (currentAccount == null || string.IsNullOrEmpty(playthroughId) || !quizResultLedgerInitialized)
        {
            Debug.LogWarning("Quiz reconciliation skipped: No initialized playthrough.");
            return false;
        }

        if (pendingNewGameReset || isResettingPlaythrough)
        {
            Debug.LogWarning("Quiz reconciliation skipped: New Game reset is not yet confirmed.");
            return false;
        }

        isReconcilingProgress = true;

        string accountId = currentAccount.id;
        string activePlaythroughId = playthroughId;
        int operationGeneration = progressGeneration;

        try
        {
            // Take a snapshot of the current pending results.
            ProgressData localSnapshot = new ProgressData
            {
                playthroughId = activePlaythroughId,
                pendingQuizResults =
                    new List<QuizResultData>(pendingQuizResults)
            };

            List<QuizResultData> validPending =
                GetValidPendingResults(
                    localSnapshot,
                    activePlaythroughId
                );

            // Read cloud counters and result IDs consistently.
            QuizReconciliationSnapshot snapshot =
                await FirestoreProgressManager
                    .GetQuizReconciliationSnapshot(
                        accountId,
                        activePlaythroughId,
                        validPending
                    );

            // Reject results if the active account or playthrough changed.
            if (IsDeletingAccount(accountId) ||
            currentAccount == null ||
            currentAccount.id != accountId ||
            playthroughId != activePlaythroughId ||
            progressGeneration != operationGeneration)
            {
                Debug.LogWarning("Reconciliation cancelled: Account or playthrough session changed.");
                return false;
            }

            if (snapshot == null ||
                snapshot.cloudProgress == null ||
                !snapshot.cloudProgress.quizResultLedgerInitialized ||
                snapshot.cloudProgress.playthroughId != activePlaythroughId)
            {
                Debug.LogWarning("Reconciliation skipped: Invalid cloud snapshot.");
                return false;
            }

            // Find results that have not reached Firestore.
            List<QuizResultData> unuploadedResults = new List<QuizResultData>();

            foreach (QuizResultData result in validPending)
            {
                if (!snapshot.uploadedResultIds.Contains(result.resultId))
                {
                    unuploadedResults.Add(result);
                }
            }

            // Identify results recorded while awaiting Firestore.
            HashSet<string> snapshotIds = new HashSet<string>();

            foreach (QuizResultData result in validPending)
            {
                snapshotIds.Add(result.resultId);
            }

            List<QuizResultData> newResults = new List<QuizResultData>();

            HashSet<string> newResultIds = new HashSet<string>();

            foreach (QuizResultData result in pendingQuizResults)
            {
                if (result == null ||
                    string.IsNullOrEmpty(result.resultId) ||
                    result.playthroughId != activePlaythroughId ||
                    snapshotIds.Contains(result.resultId) ||
                    !newResultIds.Add(result.resultId))
                {
                    continue;
                }

                newResults.Add(result);
            }

            // Begin with authoritative Firestore counters.
            ApplyCloudQuizCounters(snapshot.cloudProgress);

            // Add only results not yet reflected in Firestore.
            AddPendingResultsToCounters(unuploadedResults);

            // Preserve answers recorded during reconciliation.
            AddPendingResultsToCounters(newResults);

            // Retain results that still need synchronization.
            pendingQuizResults =
                new List<QuizResultData>(unuploadedResults);

            pendingQuizResults.AddRange(newResults);

            SaveProgress(false);

            Debug.Log("Quiz reconciliation completed. Pending results: " + pendingQuizResults.Count);

            return true;
        }

        catch (System.Exception e)
        {
            Debug.LogError("Quiz reconciliation failed: " + e.Message);

            return false;
        }

        finally
        {
            isReconcilingProgress = false;
        }
    }

    public Task SyncPendingQuizResults()
    {
        if (IsAccountDeletionInProgress)
        {
            Debug.LogWarning("Pending quiz synchronization blocked: Account deletion is in progress.");

            return Task.CompletedTask;
        }

        Task operation = SyncPendingQuizResultsInternal();

        TrackBackgroundOperation(operation);

        return operation;
    }

    public async Task SyncPendingQuizResultsInternal()
    {
        if (!CanSynchronizeWithCloud())
            return; // Keep all pending quiz results for the next online session.

        if (currentAccount != null && IsAccountBlockedFromSync(currentAccount.id))
        {
            Debug.LogWarning("Quiz synchronization blocked: Account is pending deletion.");

            return;
        }
        if (IsAccountDeletionInProgress)
        {
            Debug.LogWarning("Pending quiz synchronization skipped: Account deletion in progress.");
            return;
        }

        if (currentAccount == null)
        {
            Debug.LogWarning("Cannot sync: No active account.");
            return;
        }

        if (pendingNewGameReset || isResettingPlaythrough)
        {
            Debug.LogWarning("Quiz synchronization skipped: New Game reset is not yet confirmed.");
            return;
        }

        if (!quizResultLedgerInitialized ||
            string.IsNullOrEmpty(playthroughId))
        {
            Debug.LogWarning("Cannot sync: Quiz result ledger is not initialized.");
            return;
        }

        if (isSyncingQuizResults || isReconcilingProgress)
        {
            Debug.LogWarning("Quiz synchronization skipped: Another operation is running.");
            return;
        }

        isSyncingQuizResults = true;

        try
        {
            string accountId = currentAccount.id;
            string activePlaythroughId = playthroughId;
            int operationGeneration = progressGeneration;

            // Copy the list so gameplay can add new results during synchronization.
            List<QuizResultData> resultsToSync = new List<QuizResultData>(pendingQuizResults);

            int synchronizedCount = 0;

            foreach (QuizResultData result in resultsToSync)
            {
                if (IsDeletingAccount(accountId) ||
                    currentAccount == null ||
                    currentAccount.id != accountId ||
                    playthroughId != activePlaythroughId ||
                    progressGeneration != operationGeneration)
                {
                    Debug.LogWarning("Synchronization stopped: Active account or playthrough changed.");
                    return;
                }

                if (result == null ||
                    result.playthroughId != activePlaythroughId)
                {
                    continue;
                }

                try
                {
                    bool success =
                        await FirestoreProgressManager.UploadQuizResult(
                            accountId, result
                        );

                    if (!success)
                    {
                        Debug.LogWarning("Quiz result was not synchronized: " + result.resultId
                        );
                        continue;
                    }

                    // Confirm the active account/playthrough is still unchanged.
                    if (currentAccount == null ||
                        currentAccount.id != accountId ||
                        playthroughId != activePlaythroughId ||
                        progressGeneration != operationGeneration)
                    {
                        return;
                    }

                    // Remove only the result Firestore confirmed.
                    pendingQuizResults.RemoveAll(
                        pending => pending != null &&
                                   pending.resultId == result.resultId
                    );

                    // Persist the updated pending list locally.
                    SaveProgress(false);

                    synchronizedCount++;
                }
                catch (System.Exception e)
                {
                    Debug.LogError(
                        "Failed to synchronize quiz result " +
                        result.resultId + ": " + e.Message
                    );
                }
            }

            Debug.Log(
                "Quiz synchronization finished. Results confirmed: " +
                synchronizedCount +
                " | Remaining pending: " +
                pendingQuizResults.Count
            );
        }

        finally
        {
            isSyncingQuizResults = false;
        }
    }

    //To be used in Testing
    [ContextMenu("Test Sync Pending Quiz Results")]
    private void TestSyncPendingQuizResults()
    {
        _ = SyncPendingQuizResults();
    }


    //To be used in Testing
    [ContextMenu("Test Duplicate Quiz Result")]
    private async void TestDuplicateQuizResult()
    {
        if (currentAccount == null ||
            !quizResultLedgerInitialized ||
            string.IsNullOrEmpty(playthroughId))
        {
            Debug.LogWarning(
                "Duplicate test cancelled: No valid active playthrough."
            );
            return;
        }

        string accountId = currentAccount.id;
        string testPlaythroughId = playthroughId;

        // Create one test result with a fixed ID for both uploads.
        QuizResultData testResult = new QuizResultData()
        {
            resultId = System.Guid.NewGuid().ToString(),
            playthroughId = testPlaythroughId,
            questionType = InputType.TrueOrFalse.ToString(),
            isCorrect = true
        };

        try
        {
            Debug.Log("Duplicate test: Uploading result for the first time.");

            bool firstUpload =
                await FirestoreProgressManager.UploadQuizResult(
                    accountId, testResult
                );

            if (!firstUpload)
            {
                Debug.LogError("Duplicate test: First upload failed.");
                return;
            }

            Debug.Log("Duplicate test: Uploading the SAME result ID again.");

            bool secondUpload =
                await FirestoreProgressManager.UploadQuizResult(
                    accountId, testResult
                );

            if (!secondUpload)
            {
                Debug.LogError("Duplicate test: Second upload failed.");
                return;
            }

            Debug.Log(
                "Duplicate test completed. Both uploads were acknowledged. " +
                "Check Firestore to confirm the counters increased only once."
            );
        }
        catch (System.Exception e)
        {
            Debug.LogError(
                "Duplicate test failed: " + e.Message
            );
        }
    }

    //To be used in testing
    [ContextMenu("Test Reconcile Quiz Progress")]
    private async void TestReconcileQuizProgress()
    {
        bool success = await ReconcileQuizProgress();

        Debug.Log(
            "Manual quiz reconciliation test: " +
            (success ? "SUCCESS" : "FAILED")
        );
    }

    [ContextMenu("Test Retry Pending New Game Reset")]
    private async void TestRetryPendingNewGameReset()
    {
        bool success = await RetryPendingNewGameReset();

        Debug.Log(
            "Manual New Game retry test: " +
            (success ? "SUCCESS" : "NOT COMPLETED")
        );
    }

    private void Update()
    {

    }
}