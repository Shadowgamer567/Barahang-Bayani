using UnityEngine;

[CreateAssetMenu(fileName = "NewCampaign", menuName = "Campaign/BackgroundSet")]
public class BackgroundSet : ScriptableObject
{
    public string campaignName;

    [Header("Campaign Quiz")]
    public TextAsset campaignQuizFile;
    public TextAsset campaignQuizInfoFile;

    [Header("General Use Cards")]
    public CardType[] generalCards;
    

    [System.Serializable]
    public class LevelRange
    {
        public int startLevel;
        public int endLevel;
        public GameObject[] prefabs;
        public Material groundMaterial;
    }

    public LevelRange[] levelsRanges;

    public GameObject GetRandomPrefab(int level)
    {
        foreach (var range in levelsRanges)
        {
            if (level >= range.startLevel && level <= range.endLevel)
            {
                if (range.prefabs.Length == 0)
                {
                    return null;
                }

                return range.prefabs[Random.Range(0, range.prefabs.Length)];
            }
        }

        return null;
    }

    public Material GetGroundMaterial(int level)
    {
        foreach (var range in levelsRanges)
        {
            if (level >= range.startLevel && level <= range.endLevel)
            {
                return range.groundMaterial;
            }
        }

        return null;
    }
}
